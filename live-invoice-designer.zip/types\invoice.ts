export type InvoiceItem = {
  amount: number;
  id: number;
  name: string;
  description: string;
  sku: string;
  unit: string;
  quantity: number;
  unitPrice: number;
  discount: number;
  tax: number;
};

export type InvoiceData = {
  // ========================================================================
  // BUSINESS DETAILS
  // ========================================================================

  logo: string;
  businessName: string;

  phoneCountryCode: string;
  phone: string;

  email: string;

  // Business address
  addressHouseNumber: string;
  addressStreet: string;
  addressCity: string;
  addressState: string;
  addressDistrict: string;
  addressCountry: string;
  addressPincode: string;

  gst: string;
  website: string;

  // ========================================================================
  // BANK DETAILS
  // ========================================================================

  bankName: string;
  bankAccountNumber: string;
  bankIfscCode: string;
  bankUpiId: string;

  // ========================================================================
  // INVOICE DETAILS
  // ========================================================================

  invoiceNumber: string;
  status: string;
  invoiceDate: string;
  dueDate: string;
  paymentTerms: string;
  currency: string;
  interState: boolean;

  // ========================================================================
  // CUSTOMER / BILL TO
  // ========================================================================

  customerName: string;
  customerCompany: string;

  customerHouseNumber: string;
  customerStreet: string;
  customerCity: string;
  customerState: string;
  customerDistrict: string;
  customerCountry: string;
  customerPincode: string;

  customerPhoneCountryCode: string;
  customerPhone: string;
  customerEmail: string;
  customerGst: string;

  // ========================================================================
  // SHIPPING
  // ========================================================================

  shippingSameAsBilling: boolean;

  shippingHouseNumber: string;
  shippingStreet: string;
  shippingCity: string;
  shippingState: string;
  shippingDistrict: string;
  shippingCountry: string;
  shippingPincode: string;

  shippingPhoneCountryCode: string;
  shippingPhone: string;

  shippingGst: string;

  // Keep this temporarily if other parts of the project still use it.
  shippingAddress: string;

  // ========================================================================
  // ITEMS
  // ========================================================================

  items: InvoiceItem[];

  // ========================================================================
  // CHARGES / PAYMENT
  // ========================================================================

  otherCharges: number;
  amountPaid: number;
  roundOff: boolean;

  // ========================================================================
  // ADDITIONAL INFORMATION
  // ========================================================================

  notes: string;
  terms: string;
  paymentInstructions: string;

  // ========================================================================
  // SIGNATURE
  // ========================================================================

  requireSignature: boolean;
  signature: string;
};

export const initialInvoice: InvoiceData = {
  // ========================================================================
  // BUSINESS DETAILS
  // ========================================================================

  logo: "",

  businessName: "AKRA Solutions Pvt. Ltd.",

  phoneCountryCode: "+91",
  phone: "9876543210",

  email: "billing@akra.com",

  // Business address
  addressHouseNumber: "123",
  addressStreet: "MG Road",
  addressCity: "Hyderabad",
  addressState: "Telangana",
  addressDistrict: "Hyderabad",
  addressCountry: "India",
  addressPincode: "500001",

  gst: "36ABCDE1234F1Z5",
  website: "www.akra.com",

  // ========================================================================
  // BANK DETAILS
  // ========================================================================

  bankName: "HDFC Bank",
  bankAccountNumber: "0123456789",
  bankIfscCode: "HDFC0001234",
  bankUpiId: "akra@hdfcbank",

  // ========================================================================
  // INVOICE DETAILS
  // ========================================================================

  invoiceNumber: "INV-2026-0001",
  status: "Draft",
  invoiceDate: "2026-08-26",
  dueDate: "",
  paymentTerms: "Due on receipt",
  currency: "₹ INR",
  interState: false,

  // ========================================================================
  // CUSTOMER / BILL TO
  // ========================================================================

  customerName: "Roshini Gandla",
  customerCompany: "Gandla Textiles",

  customerHouseNumber: "",
  customerStreet: "",
  customerCity: "",
  customerState: "",
  customerDistrict: "",
  customerCountry: "India",
  customerPincode: "",

  customerPhoneCountryCode: "+91",
  customerPhone: "9000011111",

  customerEmail: "roshini@gandla.com",
  customerGst: "",

  // ========================================================================
  // SHIPPING
  // ========================================================================

  shippingSameAsBilling: true,

  shippingHouseNumber: "",
  shippingStreet: "",
  shippingCity: "",
  shippingState: "",
  shippingDistrict: "",
  shippingCountry: "India",
  shippingPincode: "",

  shippingPhoneCountryCode: "+91",
  shippingPhone: "",

  shippingGst: "",

  shippingAddress: "",

  // ========================================================================
  // ITEMS
  // ========================================================================

  items: [
    {
      id: 1,
      amount: 2000,
      name: "Website Design",
      description: "Custom 5-page responsive website",
      sku: "WEB-001",
      unit: "pcs",
      quantity: 2,
      unitPrice: 15000,
      discount: 10,
      tax: 18,
    },
  ],

  // ========================================================================
  // CHARGES / PAYMENT
  // ========================================================================

  otherCharges: 0,
  amountPaid: 0,
  roundOff: true,

  // ========================================================================
  // ADDITIONAL INFORMATION
  // ========================================================================

  notes: "Thank you for your business!",

  terms:
    "Payment due within the agreed terms. Late payments may incur a 2% monthly fee.",

  paymentInstructions:
    "Pay via bank transfer or UPI using the details above. Please include the invoice number as reference.",

  // ========================================================================
  // SIGNATURE
  // ========================================================================

  requireSignature: false,
  signature: "",
};