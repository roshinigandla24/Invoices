import InvoiceList from "@/components/invoice/invoice-list";

export default function Home() {
  return <InvoiceList />;
}