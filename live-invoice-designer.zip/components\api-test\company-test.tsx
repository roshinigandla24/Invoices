"use client";

import { useCompanyList } from "@/hooks/company/useCompanyList";

export default function CompanyTest() {
  const {
    data,
    isLoading,
    isError,
    error,
  } = useCompanyList();

  if (isLoading) {
    return <div>Loading companies...</div>;
  }

  if (isError) {
    return (
      <div>
        <h2>Company API Error</h2>
        <pre>
          {error instanceof Error
            ? error.message
            : JSON.stringify(error, null, 2)}
        </pre>
      </div>
    );
  }

  return (
    <div>
      <h2>Company API Response</h2>

      <pre>
        {JSON.stringify(data, null, 2)}
      </pre>
    </div>
  );
}