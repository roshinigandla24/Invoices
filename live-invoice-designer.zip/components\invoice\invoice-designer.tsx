"use client";

import {
  ChangeEvent,
  useMemo,
  useRef,
  useState,
} from "react";

import { InvoiceForm } from "@/components/invoice/invoice-form";
import { InvoicePreview } from "@/components/invoice/invoice-preview";

import { USInvoiceForm } from "@/components/us/us-invoice-form";
import { USInvoicePreview } from "@/components/us/us-invoice-preview";

import { calculateInvoice } from "@/lib/invoice-utils";

import {
  initialInvoice,
  InvoiceData,
  InvoiceItem,
} from "@/types/invoice";

import {
  initialUSInvoice,
  USInvoiceData,
  USInvoiceItem,
} from "@/types/us-invoice";

type InvoiceFormat = "indian" | "us";

type InvoiceDesignerProps = {
  onBack?: () => void;
};

export function InvoiceDesigner({ onBack }: InvoiceDesignerProps) {
  
  /* ================================================================
     INVOICE FORMAT
     ================================================================ */

  const [invoiceFormat, setInvoiceFormat] =
    useState<InvoiceFormat>("us");

  /* ================================================================
     INDIAN INVOICE
     ================================================================ */

  const [invoice, setInvoice] =
    useState<InvoiceData>(initialInvoice);

  const logoInputRef =
    useRef<HTMLInputElement>(null);

  const signatureInputRef =
    useRef<HTMLInputElement>(null);

  /* ================================================================
     US INVOICE
     ================================================================ */

  const [usInvoice, setUSInvoice] =
    useState<USInvoiceData>(initialUSInvoice);

  const [usZoom, setUSZoom] = useState(85);

  const usLogoInputRef =
    useRef<HTMLInputElement>(null);

  /* ================================================================
     INDIAN - UPDATE FIELD
     ================================================================ */

  const updateField = <
    K extends keyof InvoiceData
  >(
    field: K,
    value: InvoiceData[K],
  ) => {
    setInvoice((previous) => ({
      ...previous,
      [field]: value,
    }));
  };

  /* ================================================================
     INDIAN - UPDATE ITEM
     ================================================================ */

  const updateItem = (
    id: number,
    field: keyof InvoiceItem,
    value: string | number,
  ) => {
    setInvoice((previous) => ({
      ...previous,

      items: previous.items.map((item) =>
        item.id === id
          ? {
              ...item,
              [field]: value,
            }
          : item,
      ),
    }));
  };

  /* ================================================================
     INDIAN - ADD ITEM
     ================================================================ */

  const addItem = () => {
    setInvoice((previous) => ({
      ...previous,

      items: [
        ...previous.items,
        {
  id: Date.now(),
  name: "",
  description: "",
  sku: "",
  unit: "pcs",
  quantity: 1,
  unitPrice: 0,
  amount: 0,
  discount: 0,
  tax: 18,
},
      ],
    }));
  };

  /* ================================================================
     INDIAN - REMOVE ITEM
     ================================================================ */

  const removeItem = (id: number) => {
    setInvoice((previous) => ({
      ...previous,

      items:
        previous.items.length === 1
          ? previous.items
          : previous.items.filter(
              (item) => item.id !== id,
            ),
    }));
  };

  /* ================================================================
     INDIAN - IMAGE UPLOAD
     ================================================================ */

  const handleImageUpload = (
    event: ChangeEvent<HTMLInputElement>,
    field: "logo" | "signature",
  ) => {
    const file =
      event.target.files?.[0];

    if (!file) return;

    const allowedTypes = [
      "image/png",
      "image/jpeg",
      "image/webp",
    ];

    if (!allowedTypes.includes(file.type)) {
      alert(
        "Please upload a PNG, JPG or WEBP image.",
      );

      event.target.value = "";
      return;
    }

    const MAX_FILE_SIZE =
      5 * 1024 * 1024;

    if (file.size > MAX_FILE_SIZE) {
      alert(
        "Image size must be less than 5MB.",
      );

      event.target.value = "";
      return;
    }

    const reader =
      new FileReader();

    reader.onload = () => {
      updateField(
        field,
        String(reader.result),
      );
    };

    reader.onerror = () => {
      alert(
        "Unable to read the selected image.",
      );
    };

    reader.readAsDataURL(file);

    event.target.value = "";
  };

  /* ================================================================
     INDIAN - CALCULATIONS
     ================================================================ */

  const calculations = useMemo(
    () => calculateInvoice(invoice),
    [invoice],
  );

  /* ================================================================
     US - UPDATE FIELD
     ================================================================ */

  const updateUSField = <
    K extends keyof USInvoiceData
  >(
    field: K,
    value: USInvoiceData[K],
  ) => {
    setUSInvoice((previous) => ({
      ...previous,
      [field]: value,
    }));
  };

  /* ================================================================
     US - UPDATE ITEM
     ================================================================ */

  const updateUSItem = (
    id: number,
    field: keyof USInvoiceItem,
    value: string | number,
  ) => {
    setUSInvoice((previous) => ({
      ...previous,

      items: previous.items.map((item) =>
        item.id === id
          ? {
              ...item,
              [field]: value,
            }
          : item,
      ),
    }));
  };

  /* ================================================================
     US - ADD ITEM
     ================================================================ */

  const addUSItem = () => {
    setUSInvoice((previous) => ({
      ...previous,

      items: [
        ...previous.items,
        {
          id: Date.now(),
          quantity: 1,
          description: "",
          amount: 0,
        },
      ],
    }));
  };

  /* ================================================================
     US - REMOVE ITEM
     ================================================================ */

  const removeUSItem = (id: number) => {
    setUSInvoice((previous) => ({
      ...previous,

      items:
        previous.items.length === 1
          ? previous.items
          : previous.items.filter(
              (item) => item.id !== id,
            ),
    }));
  };

  /* ================================================================
     US - LOGO UPLOAD
     ================================================================ */

  const handleUSLogoUpload = (
    event: ChangeEvent<HTMLInputElement>,
  ) => {
    const file =
      event.target.files?.[0];

    if (!file) return;

    const allowedTypes = [
      "image/png",
      "image/jpeg",
      "image/webp",
    ];

    if (!allowedTypes.includes(file.type)) {
      alert(
        "Please upload a PNG, JPG or WEBP image.",
      );

      event.target.value = "";
      return;
    }

    const MAX_FILE_SIZE =
      5 * 1024 * 1024;

    if (file.size > MAX_FILE_SIZE) {
      alert(
        "Image size must be less than 5MB.",
      );

      event.target.value = "";
      return;
    }

    const reader =
      new FileReader();

    reader.onload = () => {
      updateUSField(
        "logo",
        String(reader.result),
      );
    };

    reader.onerror = () => {
      alert(
        "Unable to read the selected image.",
      );
    };

    reader.readAsDataURL(file);

    event.target.value = "";
  };

  /* ================================================================
     RESET US INVOICE
     ================================================================ */

  const resetUSInvoice = () => {
    setUSInvoice({
      ...initialUSInvoice,
      items: initialUSInvoice.items.map(
        (item) => ({
          ...item,
        }),
      ),
    });

    setUSZoom(85);
  };

  /* ================================================================
     RESET INDIAN INVOICE
     ================================================================ */

  const resetIndianInvoice = () => {
    setInvoice({
      ...initialInvoice,
      items: initialInvoice.items.map(
        (item) => ({
          ...item,
        }),
      ),
    });
  };

  /* ================================================================
     PRINT
     ================================================================ */

  const handlePrint = () => {
    window.print();
  };

  /* ================================================================
     RENDER
     ================================================================ */

  return (
    <main
      className="
        grid
        h-dvh
        w-full
        grid-cols-1
        overflow-hidden
        bg-slate-100
        md:grid-cols-[48%_52%]
        print:block
        print:bg-white
      "
    >
      {/* ============================================================
         LEFT SIDE
         ============================================================ */}

      <div
        className="
          flex
          min-h-0
          flex-col
          overflow-hidden
          border-r
          border-slate-200
          bg-white
          print:hidden
        "
      >
        {/* ==========================================================
           FORMAT SELECTOR
           ========================================================== */}
<div
  className="
    border-b
    border-slate-200
    bg-white
    px-3
    py-2
  "
>
  <div
    className="
      flex
      w-full
      items-center
      justify-between
    "
  >
    {/* BACK BUTTON + LABEL */}

    <div
      className="
        flex
        items-center
        gap-2
      "
    >
      <button
        type="button"
     
        onClick={onBack}
        title="Back to Invoices"
        aria-label="Back to Invoices"
        className="
          flex
          h-7
          w-7
          shrink-0
          items-center
          justify-center
          rounded-full
          border
          border-slate-400
          bg-white
          text-[17px]
          font-bold
          leading-none
          text-slate-800
          shadow-sm
          hover:bg-slate-50
        "
      >
        ←
      </button>

      <label
        htmlFor="invoice-format"
        className="
          whitespace-nowrap
          text-[12px]
          font-semibold
          text-slate-600
        "
      >
        Invoice Format
      </label>
    </div>

    {/* INVOICE FORMAT DROPDOWN */}

    <select
      id="invoice-format"
      value={invoiceFormat}
      onChange={(event) =>
        setInvoiceFormat(
          event.target.value as InvoiceFormat,
        )
      }
      className="
        h-7
        w-[140px]
        rounded-md
        border
        border-slate-300
        bg-white
        px-2
        text-[10px]
        font-medium
        text-slate-900
        outline-none
        focus:border-blue-500
        focus:ring-2
        focus:ring-blue-500/10
      "
    >
      <option value="us">
        US Invoice
      </option>

      <option value="indian">
      Indian Invoice
      </option>
    </select>
  </div>
</div>
        {/* ==========================================================
           SCROLLABLE FORM
           ========================================================== */}

        <div
          className="
            min-h-0
            flex-1
            overflow-y-auto
            overflow-x-hidden
            px-4
            pt-0
            pb-0
          "
        >
          {/* ========================================================
             FORMS
             Keep both forms mounted so switching format does not
             remount the entire editor or change the parent height.
             Only the selected form participates in layout.
             ======================================================== */}

          <div className="relative w-full">

            {/* INDIAN FORM */}

            <div
              className={
                invoiceFormat === "indian"
                  ? "block w-full"
                  : "hidden"
              }
            >
              <InvoiceForm
                invoice={invoice}
                logoInputRef={logoInputRef}
                signatureInputRef={signatureInputRef}
                updateField={updateField}
                updateItem={updateItem}
                addItem={addItem}
                removeItem={removeItem}
                handleImageUpload={handleImageUpload}
                onPrint={handlePrint}
                onReset={resetIndianInvoice}
              />
            </div>

            {/* US FORM */}

            <div
              className={
                invoiceFormat === "us"
                  ? "block w-full"
                  : "hidden"
              }
            >
              <USInvoiceForm
                invoice={usInvoice}
                logoInputRef={usLogoInputRef}
                updateField={updateUSField}
                updateItem={updateUSItem}
                addItem={addUSItem}
                removeItem={removeUSItem}
                handleLogoUpload={handleUSLogoUpload}
                onPrint={handlePrint}
                onReset={resetUSInvoice}
              />
            </div>

          </div>
        </div>
      </div>

      {/* ============================================================
         RIGHT SIDE - LIVE PREVIEW
         ============================================================ */}

      <div
        className="
          relative
          flex
          min-h-0
          min-w-0
          flex-col
          overflow-hidden
          bg-slate-100
          print:block
          print:overflow-visible
          print:bg-white
        "
      >
        <div className="relative min-h-0 flex-1 w-full print:block print:h-auto print:min-h-0">
          <div
            className={
              invoiceFormat === "indian"
                ? "absolute inset-0 block w-full"
                : "hidden"
            }
          >
            <InvoicePreview
              invoice={invoice}
              calculations={calculations}
            />
          </div>

          <div
            className={
              invoiceFormat === "us"
                ? "absolute inset-0 block w-full"
                : "hidden"
            }
          >
            <USInvoicePreview
              invoice={usInvoice}
              zoom={usZoom}
              onZoomOut={() =>
                setUSZoom((value) =>
                  Math.max(50, value - 5),
                )
              }
              onZoomIn={() =>
                setUSZoom((value) =>
                  Math.min(120, value + 5),
                )
              }
            />
          </div>
        </div>
      </div>
    </main>
  );
}

export default InvoiceDesigner;
