export type USInvoiceItem = {
  id: number;
  quantity: number;
  description: string;
  amount: number;
};

export type USInvoiceData = {
  logo: string;

  businessName: string;
  houseStreet: string;
  city: string;
  state: string;
  zipCode: string;
  country: string;

  invoiceNumber: string;
  invoiceDate: string;
  dueDate: string;
  paymentTerms: string;

  // Currency
  currency: string;

  customerName: string;
  customerStreet: string;
  customerCity: string;
  customerState: string;
  customerZipCode: string;
  customerCountry: string;
  customerPhone: string;
  customerEmail: string;
  phoneCountryCode: string;

  bankName: string;
  routingNumber: string;
  accountNumber: string;
  paymentMethod: string;

  notes: string;

  requireSignature: boolean;
  signature: string;
  zoom: number;
  items: USInvoiceItem[];
};

export const initialUSInvoice: USInvoiceData = {
  logo: "",

  businessName: "AKRA Solutions LLC",
  houseStreet: "1 Marina Park Dr, Suite 1410",
  city: "Boston",
  state: "MA",
  zipCode: "02210",
  country: "USA",

  invoiceNumber: "2026-1010",
  invoiceDate: "2026-01-10",
  dueDate: "2026-01-17",
  paymentTerms: "7 days",

  // Default currency
  currency: "$ USD",

  customerName: "Scholar IT Solutions Inc",
  customerStreet: "3057 PeachTree Industrial Blvd Ste 110",
  customerCity: "Atlanta",
  customerState: "GA",
  customerZipCode: "30097",
  customerCountry: "USA",
  customerPhone: "678 387 2929",
  customerEmail: "contracts@scholaritin.com",
  phoneCountryCode: "+1",

  bankName: "Digital Federal Credit Union",
  routingNumber: "211391825",
  accountNumber: "47193636",
  paymentMethod: "",
  notes: "Please remit the payment by due date to AKRA Solutions LLC.",

  requireSignature: false,
  signature: "",

  items: [
    {
      id: 1,
      quantity: 1,
      description: "Invoice for Services for Dec 2025",
      amount: 7698.8,
    },
  ],

  zoom: 0,
};