"use client";

import {
  ChangeEvent,
  ReactNode,
  RefObject,
  useEffect,
  useRef,
  useState,
} from "react";

import {
  USInvoiceData,
  USInvoiceItem,
} from "@/types/us-invoice";

import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";

import { useCompanyList } from "@/hooks/company/useCompanyList";
import { useInvoiceBankDetails } from "@/hooks/company/useInvoiceBankDetails";
import { useCustomerList } from "@/hooks/customer/useCustomerList";
import type { Company } from "@/types/invoice-api";
import type { Customer } from "@/types/invoice-api";

const DEFAULT_NOTES =
  "Please remit the payment by due date to AKRA Investment Services Inc";

type USInvoiceFormProps = {
  invoice: USInvoiceData;

  logoInputRef: RefObject<HTMLInputElement | null>;

  updateField: <K extends keyof USInvoiceData>(
    field: K,
    value: USInvoiceData[K]
  ) => void;

  updateItem: (
    id: number,
    field: keyof USInvoiceItem,
    value: string | number
  ) => void;

  addItem: () => void;
  removeItem: (id: number) => void;

  handleLogoUpload: (
    event: ChangeEvent<HTMLInputElement>
  ) => void;

  onPrint: () => void;
  onReset: () => void;
};

export function USInvoiceForm({
  invoice,
  logoInputRef,
  updateField,
  updateItem,
  addItem,
  removeItem,
  handleLogoUpload,
  onPrint,
  onReset,
}: USInvoiceFormProps) {
  const signatureInputRef =
    useRef<HTMLInputElement>(null);

  /* =====================================================
     DEFAULT NOTES
     The note is initialized once and remains fully editable.
  ===================================================== */
  const notesInitializedRef = useRef(false);

  useEffect(() => {
    if (notesInitializedRef.current) {
      return;
    }

    notesInitializedRef.current = true;

    if (!invoice.notes) {
      updateField("notes", DEFAULT_NOTES);
    }
  }, [invoice.notes, updateField]);
  /* =====================================================
     COMPANY LIST
  ===================================================== */

  const { data: companyResponse } =
    useCompanyList();

  const companies: Company[] =
    companyResponse?.items ??
    (
      companyResponse as unknown as {
        data?: {
          items?: Company[];
        };
      }
    )?.data?.items ??
    [];

  const [selectedCompanyId, setSelectedCompanyId] =
    useState<string>("");

  /* =====================================================
     CUSTOMER LIST
     API requires CompanyID
  ===================================================== */

  const {
    data: customerResponse,
    isLoading: isCustomersLoading,
  } = useCustomerList(selectedCompanyId);

  const customers: Customer[] =
    customerResponse?.items ??
    (
      customerResponse as unknown as {
        data?: {
          items?: Customer[];
        };
      }
    )?.data?.items ??
    [];

  const [selectedCustomerId, setSelectedCustomerId] =
    useState<string>("");

  /* =====================================================
     BUSINESS ADDRESS 2
     ===================================================== */

  const invoiceWithAddress2 =
    invoice as USInvoiceData & {
      address2?: string;
    };

  const updateAddress2 = (value: string) => {
    (updateField as unknown as (
      field: "address2",
      value: string,
    ) => void)("address2", value);
  };

  /* =====================================================
     BANK DETAILS
  ===================================================== */

  const selectedCustomerForBank =
  customers.find(
    (customer) =>
      String(customer.CustomerId) ===
      selectedCustomerId,
  );

const companyIdForBankDetails =
  selectedCustomerForBank?.CompanyID
    ? Number(selectedCustomerForBank.CompanyID)
    : selectedCompanyId
      ? Number(selectedCompanyId)
      : null;
      const {
  data: bankDetails = [],
} = useInvoiceBankDetails(
  companyIdForBankDetails,
);

  /* =====================================================
     INITIAL CLEAR
     Do not show default company/customer/payment values
     before the user selects a company.
  ===================================================== */

  const initialFieldsClearedRef =
    useRef(false);

  useEffect(() => {
    if (initialFieldsClearedRef.current) {
      return;
    }

    initialFieldsClearedRef.current = true;

    updateField("businessName", "");
    updateField("houseStreet", "");
    updateAddress2("");
    updateField("city", "");
    updateField("state", "");
    updateField("zipCode", "");
    updateField("country", "");

    updateField("customerName", "");
    updateField("customerStreet", "");
    updateField("customerCity", "");
    updateField("customerState", "");
    updateField("customerZipCode", "");
    updateField("customerCountry", "");
    updateField("phoneCountryCode", "");
    updateField("customerPhone", "");
    updateField("customerEmail", "");

    updateField("bankName", "");
    updateField("routingNumber", "");
    updateField("accountNumber", "");
  }, [updateField]);

  /* =====================================================
     CUSTOMER SELECTION
     Select customer and populate customer fields
  ===================================================== */

  const handleCustomerChange = (
    event: ChangeEvent<HTMLSelectElement>,
  ) => {
    const customerId =
      event.target.value;

    setSelectedCustomerId(customerId);

    if (!customerId) {
      updateField("customerName", "");
      updateField("customerStreet", "");
      updateField("customerCity", "");
      updateField("customerState", "");
      updateField("customerZipCode", "");
      updateField("customerCountry", "");
      updateField("phoneCountryCode", "");
      updateField("customerPhone", "");
      updateField("customerEmail", "");
      return;
    }

    const selectedCustomer =
      customers.find(
        (customer) =>
          String(customer.CustomerId) ===
          customerId,
      );

    if (!selectedCustomer) {
      return;
    }

    updateField(
      "customerName",
      selectedCustomer.CustomerName || "",
    );

    updateField(
      "customerStreet",
      [
        selectedCustomer.Address1,
        selectedCustomer.Address2,
      ]
        .filter(Boolean)
        .join(", "),
    );

    updateField(
      "customerCity",
      selectedCustomer.City || "",
    );

    updateField(
      "customerState",
      selectedCustomer.State || "",
    );

    updateField(
      "customerZipCode",
      selectedCustomer.ZipCode || "",
    );

    updateField(
      "customerCountry",
      selectedCustomer.Country || "",
    );

    updateField(
      "phoneCountryCode",
      selectedCustomer.PhoneCountryCode || "",
    );

    updateField(
      "customerPhone",
      selectedCustomer.Phone || "",
    );

    updateField(
      "customerEmail",
      selectedCustomer.Email || "",
    );
  };

  /* =====================================================
     COMPANY SELECTION
     Select company and populate business fields
     immediately. This avoids an update loop from useEffect.
  ===================================================== */

  const handleCompanyChange = (
    event: ChangeEvent<HTMLSelectElement>,
  ) => {
    const companyId =
      event.target.value;

    setSelectedCompanyId(companyId);

    /* Clear customer selection/details. */
    setSelectedCustomerId("");

    updateField("customerName", "");
    updateField("customerStreet", "");
    updateField("customerCity", "");
    updateField("customerState", "");
    updateField("customerZipCode", "");
    updateField("customerCountry", "");
    updateField("phoneCountryCode", "");
    updateField("customerPhone", "");
    updateField("customerEmail", "");

    /* Clear bank details until API returns new company data. */
    updateField("bankName", "");
    updateField("routingNumber", "");
    updateField("accountNumber", "");

    if (!companyId) {
      updateField("businessName", "");
      updateField("houseStreet", "");
      updateAddress2("");
      updateField("city", "");
      updateField("state", "");
      updateField("zipCode", "");
      updateField("country", "");
      return;
    }

    const selectedCompany =
      companies.find(
        (company) =>
          String(company.CompanyID) ===
          companyId,
      );

    if (!selectedCompany) {
      return;
    }

    updateField(
      "businessName",
      selectedCompany.DisplayCompanyName ||
        selectedCompany.CompanyName ||
        "",
    );

    updateField(
      "houseStreet",
      selectedCompany.Address1 || "",
    );

    updateAddress2(
      selectedCompany.Address2 || "",
    );

    updateField(
      "city",
      selectedCompany.City || "",
    );

    updateField(
      "state",
      selectedCompany.State || "",
    );

    updateField(
      "zipCode",
      selectedCompany.ZipCode || "",
    );

    updateField(
      "country",
      selectedCompany.Country || "",
    );
  };

  /* =====================================================
     BANK DETAILS
     Populate payment information after the bank API
     returns the selected company's details.

     The ref prevents the effect from repeatedly calling
     updateField when updateField itself changes identity.
  ===================================================== */

  const appliedBankKeyRef =
    useRef("");

  useEffect(() => {
    if (!companyIdForBankDetails) {
  appliedBankKeyRef.current = "";
  return;
}

    if (bankDetails.length === 0) {
      return;
    }

    const bank = bankDetails[0];
const bankKey = [
  companyIdForBankDetails,
  bank.BankName || "",
  bank.RoutingNumber || "",
  String(bank.AccountNumber ?? ""),
].join("|");

    if (
      appliedBankKeyRef.current ===
      bankKey
    ) {
      return;
    }

    appliedBankKeyRef.current = bankKey;

    updateField(
      "bankName",
      bank.BankName || "",
    );

    updateField(
      "routingNumber",
      bank.RoutingNumber || "",
    );

    updateField(
      "accountNumber",
      String(bank.AccountNumber ?? ""),
    );
  }, [
    companyIdForBankDetails,
    bankDetails,
    updateField,
  ]);


  /* =====================================================
     SIGNATURE UPLOAD
  ===================================================== */

  const handleSignatureUpload = (
    event: ChangeEvent<HTMLInputElement>
  ) => {
    const file =
      event.target.files?.[0];

    if (!file) {
      return;
    }

    const allowedTypes = [
      "image/png",
      "image/jpeg",
      "image/webp",
    ];

    if (!allowedTypes.includes(file.type)) {
      alert(
        "Please upload a PNG, JPG or WEBP image."
      );

      event.target.value = "";
      return;
    }

    const maxFileSize =
      5 * 1024 * 1024;

    if (file.size > maxFileSize) {
      alert(
        "Image size must be less than 5MB."
      );

      event.target.value = "";
      return;
    }

    const reader =
      new FileReader();

    reader.onload = () => {
      updateField(
        "signature",
        String(reader.result)
      );
    };

    reader.onerror = () => {
      alert(
        "Unable to read the selected image."
      );
    };

    reader.readAsDataURL(file);

    event.target.value = "";
  };

  /* =====================================================
     SUBMIT / CANCEL
     Stores submitted US invoice in browser storage.
  ===================================================== */

  const handleSubmit = () => {
    if (!invoice.invoiceNumber.trim()) {
      alert("Please enter an invoice number.");
      return;
    }

    const total = invoice.items.reduce(
      (sum, item) =>
        sum +
        Number(item.quantity || 0) *
          Number(item.amount || 0),
      0
    );

    const formatDate = (value: string) => {
      if (!value) {
        return "";
      }

      const parts = value.split("-");

      if (parts.length !== 3) {
        return value;
      }

      return `${parts[1]}/${parts[2]}/${parts[0]}`;
    };

    const payload = {
      RequestParamType: "SaveInvoice",
      json: {
        InvoiceNumber: invoice.invoiceNumber,
        CustomerID: selectedCustomerId,
        CompanyName: invoice.businessName,
        CompanyCode:
          companies.find(
            (company) =>
              String(company.CompanyID) === selectedCompanyId,
          )?.CompanyCode || "",
        InvoiceDate: invoice.invoiceDate,
        DueDate: invoice.dueDate,
        PaymentTerms: invoice.paymentTerms,
        Currency: invoice.currency,
        PaymentMethod: invoice.paymentMethod,
        
        Notes: invoice.notes || null,
        Status: "Pending",
        IsActive: true,
        Items: invoice.items.map((item) => ({
          Description: item.description || "",
          Quantity: Number(item.quantity ?? 0),
          
          Amount: Number(item.amount ?? 0),
        })),
      },
    };

    console.log("SaveInvoice Payload:", payload);

    const submittedInvoice = {
      id: Date.now(),
      invoiceNumber: invoice.invoiceNumber,
      format: "US Invoice",
      businessName: invoice.businessName,
      customer: invoice.customerName,
      date: formatDate(invoice.invoiceDate),
      dueDate: formatDate(invoice.dueDate),
      paymentTerms: invoice.paymentTerms,
      currency: invoice.currency,
      amount: total,
      status: "Pending",
    };

    try {
      const existing = JSON.parse(
        localStorage.getItem(
          "invoice-list-submitted"
        ) || "[]"
      );

      const records = Array.isArray(existing)
        ? existing
        : [];

      localStorage.setItem(
        "invoice-list-submitted",
        JSON.stringify([
          ...records,
          submittedInvoice,
        ])
      );

      window.location.href = "/";
    } catch {
      alert("Unable to save the invoice.");
    }
  };

  const handleCancel = () => {
    window.location.href = "/";
  };

  /* =====================================================
     RETURN
  ===================================================== */

  return (
    <section
      className="
        relative
        flex
        h-full
        min-h-0
        flex-col
        bg-white
      "
    >
      {/* =================================================
          HEADER
      ================================================= */}

      <div
        className="
          shrink-0
          border-b
          border-slate-200
          bg-white
          px-3
          pt-1
          pb-1
        "
      >
        <div className="h-8 w-full rounded-lg bg-[#2F4F3E] px-4 flex items-center">
          <h1 className="text-lg font-bold tracking-tight text-white">
            US Invoice
          </h1>
        </div>

        <p className="mt-0.5 text-[10px] text-slate-500">
          Fill in the details and see your invoice update instantly.
        </p>
      </div>

      {/* =================================================
          SCROLLABLE FORM
      ================================================= */}

      <div
        className="
          min-h-0
          flex-1
          overflow-y-auto
          px-3
          pb-16
          pt-0
        "
      >
        {/* =================================================
            BUSINESS DETAILS
        ================================================= */}

        <div className="relative mt-4 mb-5 rounded-lg border border-slate-200 bg-white p-2 pt-3">
          <SectionTitle
            title="BUSINESS DETAILS"
          />

        {/* =================================================
            BUSINESS DETAILS + LOGO
            COMPANY NAME / ADDRESS1 / ADDRESS2
            CITY / STATE / ZIP CODE / COUNTRY
        ================================================= */}

        <div className="relative mb-2 pr-[100px]">

          {/* FIRST ROW */}
          <div className="grid grid-cols-3 gap-x-2 gap-y-1">

            <Field label="Company name">
              <select
                value={selectedCompanyId}
                onChange={handleCompanyChange}
                className={`${selectClass} !text-[9px] !text-slate-900`}
              >
                <option value="">
                  {companies.length > 0
                    ? "Select company"
                    : "Loading companies..."}
                </option>

                {companies.map((company) => (
                  <option
                    key={company.CompanyID}
                    value={String(company.CompanyID)}
                  >
                    {company.DisplayCompanyName ||
                      company.CompanyName}
                  </option>
                ))}
              </select>
            </Field>

            <Field label="Address1">
              <Input
                value={invoice.houseStreet}
                onChange={(event) =>
                  updateField(
                    "houseStreet",
                    event.target.value,
                  )
                }
                className={inputClass}
              />
            </Field>

            <Field label="Address2">
              <Input
                value={invoiceWithAddress2.address2 || ""}
                onChange={(event) =>
                  updateAddress2(event.target.value)
                }
                className={inputClass}
              />
            </Field>

          </div>

          {/* SECOND ROW */}
          <div className="mt-1 grid grid-cols-4 gap-x-2 gap-y-1">

            <Field label="City">
              <Input
                value={invoice.city}
                onChange={(event) =>
                  updateField(
                    "city",
                    event.target.value,
                  )
                }
                className={inputClass}
              />
            </Field>

            <Field label="State">
              <Input
                value={invoice.state}
                onChange={(event) =>
                  updateField(
                    "state",
                    event.target.value,
                  )
                }
                className={inputClass}
              />
            </Field>

            <Field label="ZIP code">
              <Input
                value={invoice.zipCode}
                onChange={(event) =>
                  updateField(
                    "zipCode",
                    event.target.value,
                  )
                }
                className={inputClass}
              />
            </Field>

            <Field label="Country">
              <Input
                value={invoice.country}
                onChange={(event) =>
                  updateField(
                    "country",
                    event.target.value,
                  )
                }
                className={inputClass}
              />
            </Field>

          </div>

          {/* LOGO - RIGHT SIDE */}
          <div className="absolute right-0 top-0">

            <button
              type="button"
              onClick={() => {
                if (logoInputRef.current) {
                  logoInputRef.current.value = "";
                  logoInputRef.current.click();
                }
              }}
              className="
                group
                relative
                flex
                h-[102px]
                w-[88px]
                cursor-pointer
                items-center
                justify-center
                overflow-hidden
                rounded-md
                border
                border-dashed
                border-slate-300
                bg-slate-50
                transition-all
                hover:border-blue-400
                hover:bg-blue-50/30
                focus:outline-none
                focus:ring-2
                focus:ring-blue-500/20
              "
            >
              {invoice.logo ? (
                <>
                  <img
                    src={invoice.logo}
                    alt="Business logo"
                    className="
                      h-[85%]
                      w-[85%]
                      object-contain
                      p-1.5
                    "
                  />

                  <div
                    className="
                      absolute
                      inset-0
                      flex
                      items-center
                      justify-center
                      bg-slate-900/50
                      opacity-0
                      transition-opacity
                      group-hover:opacity-100
                    "
                  >
                    <span
                      className="
                        rounded-md
                        bg-white
                        px-2
                        py-1
                        text-[9px]
                        font-medium
                        text-slate-700
                        shadow-sm
                      "
                    >
                      Replace
                    </span>
                  </div>
                </>
              ) : (
                <div className="flex flex-col items-center justify-center">
                  <div className="mb-1 text-2xl font-light leading-none text-slate-400 transition-colors group-hover:text-blue-500">
                    ↑
                  </div>

                  <span className="text-[8px] font-medium text-slate-600 group-hover:text-blue-600">
                    Upload logo
                  </span>
                </div>
              )}
            </button>

            {invoice.logo && (
              <button
                type="button"
                aria-label="Remove logo"
                onClick={() => updateField("logo", "")}
                className="
                  absolute
                  -right-1.5
                  -top-1.5
                  z-10
                  flex
                  h-5
                  w-5
                  items-center
                  justify-center
                  rounded-full
                  border
                  border-white
                  bg-red-400
                  text-[12px]
                  font-bold
                  leading-none
                  text-white
                  shadow-sm
                  transition-colors
                  hover:bg-red-600
                  focus:outline-none
                  focus:ring-2
                  focus:ring-red-500/30
                "
              >
                ×
              </button>
            )}

          </div>

          {/* Hidden file input for US logo upload */}
          <input
            ref={logoInputRef}
            type="file"
            accept="image/png,image/jpeg,image/webp"
            className="hidden"
            onChange={handleLogoUpload}
          />

        </div>

        </div>

        {/* =================================================
            INVOICE DETAILS
            4 COLUMNS
        ================================================= */}

        <div className="relative mb-5 rounded-lg border border-slate-200 bg-white p-2 pt-3">
          <SectionTitle
            title="INVOICE DETAILS"
          />

        <div
          className="
            grid
            grid-cols-4
            gap-x-2
            gap-y-1
          "
        >
          {/* INVOICE NUMBER */}

          <Field label="Invoice number">
            <Input
              value={invoice.invoiceNumber}
              onChange={(event) =>
                updateField(
                  "invoiceNumber",
                  event.target.value
                )
              }
              className={inputClass}
            />
          </Field>

          {/* PAYMENT TERMS */}

          <Field label="Payment terms">
            <Input
              value={invoice.paymentTerms}
              onChange={(event) =>
                updateField(
                  "paymentTerms",
                  event.target.value
                )
              }
              className={inputClass}
            />
          </Field>

          {/* INVOICE DATE */}

          <Field label="Invoice date">
            <Input
              type="date"
              value={invoice.invoiceDate}
              onChange={(event) =>
                updateField(
                  "invoiceDate",
                  event.target.value
                )
              }
              className={inputClass}
            />
          </Field>

          {/* DUE DATE */}

          <Field label="Due date">
            <Input
              type="date"
              value={invoice.dueDate}
              onChange={(event) =>
                updateField(
                  "dueDate",
                  event.target.value
                )
              }
              className={inputClass}
            />
          </Field>
        </div>

        </div>

        {/* =================================================
            CUSTOMER / BILL TO
            3 COLUMNS
        ================================================= */}

        <div className="relative mb-5 rounded-lg border border-slate-200 bg-white p-2 pt-3">
          <SectionTitle
            title="CUSTOMER / BILL TO"
          />

          <div className="grid grid-cols-3 gap-x-2 gap-y-1">
          {/* CUSTOMER NAME */}

          <Field label="Customer name">
            <select
              value={selectedCustomerId}
              onChange={handleCustomerChange}
              className={`${selectClass} !text-[9px] !text-slate-900`}
            >
              <option value="">
  {!selectedCompanyId
    ? "Select company first"
    : isCustomersLoading
      ? "Loading customers..."
      : customers.length > 0
        ? "Select customer"
        : "No customers"}
</option>

              {customers.map((customer) => (
                <option
                  key={customer.CustomerId}
                  value={String(customer.CustomerId)}
                >
                  {customer.CustomerName}
                </option>
              ))}
            </select>
          </Field>
          {/* CUSTOMER STREET */}

          <Field label="Address1">
            <Input
              value={invoice.customerStreet}
              onChange={(event) =>
                updateField(
                  "customerStreet",
                  event.target.value
                )
              }
              className={inputClass}
            />
          </Field>
          </div>

          <div className="mt-1 grid grid-cols-4 gap-x-2 gap-y-1">
          {/* CUSTOMER CITY */}

          <Field label="City">
            <Input
              value={invoice.customerCity}
              onChange={(event) =>
                updateField(
                  "customerCity",
                  event.target.value
                )
              }
              className={inputClass}
            />
          </Field>
          {/* CUSTOMER STATE */}

          <Field label="State">
            <Input
              value={invoice.customerState}
              onChange={(event) =>
                updateField(
                  "customerState",
                  event.target.value
                )
              }
              className={inputClass}
            />
          </Field>
          {/* CUSTOMER ZIP */}

          <Field label="ZIP code">
            <Input
              value={invoice.customerZipCode}
              onChange={(event) =>
                updateField(
                  "customerZipCode",
                  event.target.value
                )
              }
              className={inputClass}
            />
          </Field>
          {/* CUSTOMER COUNTRY */}

          <Field label="Country">
            <Input
              value={invoice.customerCountry}
              onChange={(event) =>
                updateField(
                  "customerCountry",
                  event.target.value
                )
              }
              className={inputClass}
            />
          </Field>
          </div>

        {/* =================================================
            PHONE / EMAIL
            3 COLUMNS
        ================================================= */}

        <div
          className="
            mt-1
            grid
            grid-cols-3
            gap-x-2
            gap-y-1
          "
        >
          {/* PHONE CODE */}

          <Field label="Phone code">
            <select
              value={invoice.phoneCountryCode}
              onChange={(event) =>
                updateField(
                  "phoneCountryCode",
                  event.target.value
                )
              }
              className={`${selectClass} !h-8 !text-[11px] !text-slate-900`}
            >
              <option value="">
                Select
              </option>

              <option value="+1">
                +1
              </option>

              <option value="+91">
                +91
              </option>

              <option value="+44">
                +44
              </option>

              <option value="+61">
                +61
              </option>

              <option value="+971">
                +971
              </option>

              <option value="+65">
                +65
              </option>

              <option value="+81">
                +81
              </option>

              <option value="+49">
                +49
              </option>

              <option value="+33">
                +33
              </option>
            </select>
          </Field>

          {/* PHONE */}

          <Field label="Phone">
            <Input
              value={invoice.customerPhone}
              onChange={(event) =>
                updateField(
                  "customerPhone",
                  event.target.value
                )
              }
              className={inputClass}
            />
          </Field>

          {/* EMAIL */}

          <Field label="Email">
            <Input
              type="email"
              value={invoice.customerEmail}
              onChange={(event) =>
                updateField(
                  "customerEmail",
                  event.target.value
                )
              }
              className={inputClass}
            />
          </Field>
        </div>

        </div>

        {/* =================================================
            ITEMS / SERVICES
        ================================================= */}

        <div className="relative mb-5 rounded-lg border border-slate-200 bg-white p-2 pt-3">
          <SectionTitle title="ITEMS / SERVICES" />

        <div className="space-y-2">
          {invoice.items.map((item, index) => (
            <div
              key={item.id}
              className="
                rounded-md
                border
                border-slate-200
                bg-white
                p-2
              "
            >
              {/* ITEM HEADER */}

              <div className="mb-1.5 flex items-center justify-between">
                <span
                  className="
                    text-[9px]
                    font-semibold
                    text-slate-700
                  "
                >
                  Item {index + 1}
                </span>

                <div className="flex items-center gap-1">
                  {/* ADD ITEM */}

                  <button
                    type="button"
                    onClick={addItem}
                    className="
                      flex
                      h-6
                      w-6
                      shrink-0
                      items-center
                      justify-center
                      rounded-md
                      border
                      border-[#009F6B]
                      bg-transparent
                      p-0
                      text-[15px]
                      font-medium
                      leading-none
                      text-[#009F6B]
                      transition-colors
                      hover:bg-[#009F6B]
                      hover:text-white
                    "
                    aria-label="Add item"
                  >
                    +
                  </button>

                  {/* DELETE ITEM */}

                  {invoice.items.length > 1 && (
                    <button
                      type="button"
                      onClick={() =>
                        removeItem(item.id)
                      }
                      className="
                        flex
                        h-6
                        w-6
                        shrink-0
                        items-center
                        justify-center
                        rounded-md
                        border
                        border-red-400
                        bg-transparent
                        p-0
                        text-red-400
                        transition-colors
                        hover:bg-red-400
                        hover:text-white
                      "
                      aria-label="Delete item"
                    >
                      <svg
                        width="14"
                        height="14"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2.5"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      >
                        <path d="M3 6h18" />
                        <path d="M8 6V4h8v2" />
                        <path d="M19 6l-1 14H6L5 6" />
                        <path d="M10 11v5" />
                        <path d="M14 11v5" />
                      </svg>
                    </button>
                  )}
                </div>
              </div>

              {/* ITEM FIELDS */}

              <div
                className="
                  grid
                  grid-cols-[55px_minmax(0,1fr)_105px_105px]
                  gap-2
                "
              >
                {/* QUANTITY */}

                <Field label="Qty">
                  <Input
                    type="number"
                    min="0"
                    value={item.quantity}
                    onChange={(event) =>
                      updateItem(
                        item.id,
                        "quantity",
                        Number(event.target.value)
                      )
                    }
                    className={inputClass}
                  />
                </Field>

                {/* DESCRIPTION */}

                <Field label="Description">
                  <Input
                    value={item.description}
                    onChange={(event) =>
                      updateItem(
                        item.id,
                        "description",
                        event.target.value
                      )
                    }
                    className={inputClass}
                  />
                </Field>

                {/* CURRENCY */}

                <Field label="Currency">
                  <select
                    value={invoice.currency}
                    onChange={(event) =>
                      updateField(
                        "currency",
                        event.target.value
                      )
                    }
                    className="
                      !h-8
                      w-full
                      rounded-md
                      border
                      border-slate-300
                      bg-white
                      px-1.5
                      !text-[9px]
                      !font-normal
                      !leading-6
                      text-slate-900
                      outline-none
                      focus:border-slate-500
                      focus:ring-1
                      focus:ring-slate-500/10
                    "
                  >
                    <option value="₹ INR">
                      ₹ INR
                    </option>

                    <option value="$ USD">
                      $ USD
                    </option>

                    <option value="€ EUR">
                      € EUR
                    </option>

                    <option value="£ GBP">
                      £ GBP
                    </option>

                    <option value="¥ JPY">
                      ¥ JPY
                    </option>

                    <option value="C$ CAD">
                      C$ CAD
                    </option>

                    <option value="A$ AUD">
                      A$ AUD
                    </option>

                    <option value="CHF CHF">
                      CHF CHF
                    </option>

                    <option value="د.إ AED">
                      د.إ AED
                    </option>

                    <option value="﷼ SAR">
                      ﷼ SAR
                    </option>
                  </select>
                </Field>

                {/* AMOUNT */}

                <Field label="Amount">
                  <Input
                    type="number"
                    min="0"
                    step="0.01"
                    value={item.amount}
                    onChange={(event) =>
                      updateItem(
                        item.id,
                        "amount",
                        Number(event.target.value)
                      )
                    }
                    className={inputClass}
                  />
                </Field>
              </div>
            </div>
          ))}
        </div>

        </div>

        {/* =================================================
            PAYMENT INFORMATION
            4 COLUMNS
        ================================================= */}

        <div className="relative mb-5 rounded-lg border border-slate-200 bg-white p-2 pt-3">
          <SectionTitle
            title="PAYMENT INFORMATION"
          />

        <div
          className="
            rounded-md
            border
            border-slate-200
            bg-white
            p-2
          "
        >
          <div
            className="
              grid
              grid-cols-4
              gap-2
            "
          >
            {/* BANK NAME */}

            <Field label="Bank name">
              <Input
                value={invoice.bankName}
                onChange={(event) =>
                  updateField(
                    "bankName",
                    event.target.value
                  )
                }
                className={inputClass}
              />
            </Field>

            {/* ROUTING NUMBER */}

            <Field label="Routing number">
              <Input
                value={invoice.routingNumber}
                onChange={(event) =>
                  updateField(
                    "routingNumber",
                    event.target.value
                  )
                }
                className={inputClass}
              />
            </Field>

            {/* ACCOUNT NUMBER */}

            <Field label="Account number">
              <Input
                value={invoice.accountNumber}
                onChange={(event) =>
                  updateField(
                    "accountNumber",
                    event.target.value
                  )
                }
                className={inputClass}
              />
            </Field>

            {/* MODE OF PAYMENT */}

            <Field label="Mode of payment">
              <select
                value={invoice.paymentMethod}
                onChange={(event) =>
                  updateField(
                    "paymentMethod",
                    event.target.value
                  )
                }
                className={`${selectClass} !h-8 !text-[11px] !text-slate-900 !border-slate-300 !rounded-md`}
              >
                <option value="">
                  Select payment method
                </option>

                <option value="Cash">
                  Cash
                </option>

                <option value="Credit Card">
                  Credit Card
                </option>

                <option value="Debit Card">
                  Debit Card
                </option>

                <option value="Bank Transfer">
                  Bank Transfer
                </option>

                <option value="UPI">
                  UPI
                </option>

                <option value="Cheque">
                  Cheque
                </option>

                <option value="PayPal">
                  PayPal
                </option>

                <option value="Other">
                  Other
                </option>
              </select>
            </Field>

            {/* NOTES */}

            <div className="col-span-4">
              <Field label="Notes">
                <Textarea
                  value={invoice.notes}
                  onChange={(event) =>
                    updateField(
                      "notes",
                      event.target.value
                    )
                  }
                  className="
                    h-8
                    min-h-8
                    w-full
                    resize-none
                    px-1.5
                    py-0
                    text-left
                    text-[9px]
                    leading-6
                  "
                />
              </Field>
            </div>
          </div>
        </div>

       

        </div>

        {/* =================================================
            CUSTOMER SIGNATURE
        ================================================= */}

        <div
          className="
            mt-3
            border-t
            border-slate-200
            pt-3
          "
        >
          <label
            className="
              flex
              cursor-pointer
              items-center
              gap-2
              text-[10px]
              font-medium
              text-slate-700
            "
          >
            <input
              type="checkbox"
              checked={
                invoice.requireSignature
              }
              onChange={(event) =>
                updateField(
                  "requireSignature",
                  event.target.checked
                )
              }
              className="
                h-4
                w-4
                accent-emerald-600
              "
            />

            Require customer signature
          </label>

          {/* SIGNATURE BOX */}

          {invoice.requireSignature && (
            <div className="mt-2">
              <input
                ref={signatureInputRef}
                type="file"
                accept="image/png,image/jpeg,image/webp"
                className="hidden"
                onChange={
                  handleSignatureUpload
                }
              />

              <button
                type="button"
                onClick={() => {
                  if (
                    signatureInputRef.current
                  ) {
                    signatureInputRef.current.value =
                      "";

                    signatureInputRef.current.click();
                  }
                }}
                className="
                  flex
                  h-[76px]
                  w-[140px]
                  cursor-pointer
                  flex-col
                  items-center
                  justify-center
                  overflow-hidden
                  rounded-md
                  border
                  border-dashed
                  border-slate-300
                  bg-slate-50
                  transition
                  hover:bg-slate-100
                "
              >
                {invoice.signature ? (
                  <img
                    src={invoice.signature}
                    alt="Customer signature"
                    className="
                      max-h-[62px]
                      max-w-[125px]
                      object-contain
                    "
                  />
                ) : (
                  <>
                    <svg
                      width="25"
                      height="25"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="1.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="
                        mb-1
                        text-slate-400
                      "
                    >
                      <path d="M12 20h9" />

                      <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L8 18l-4 1 1-4Z" />
                    </svg>

                    <span
                      className="
                        text-[9px]
                        font-medium
                        text-slate-600
                      "
                    >
                      Upload signature
                    </span>
                  </>
                )}
              </button>
            </div>
          )}
        </div>

        <div className="h-2" />
      </div>

      {/* =================================================
          BOTTOM ACTION BAR
          PRINT + NEW INVOICE ON LEFT
          CANCEL + SUBMIT ON RIGHT
      ================================================= */}

      <div
        className="
          absolute
          bottom-0
          left-0
          right-0
          z-20
          flex
          items-center
          border-t
          border-slate-200
          bg-white
          px-3
          py-2
        "
      >
        {/* LEFT ACTIONS */}

        <div className="flex items-center gap-2">
          <Button
            type="button"
            onClick={onPrint}
            className="
              !h-7
              !min-h-0
              !rounded-md
              !border-[#2F4F3E]
              !bg-[#2F4F3E]
              !px-3
              !py-0
              !text-xs
              !font-medium
              !leading-none
              !text-white
              hover:!bg-[#264334]
            "
          >
            🖨 Print / Save as PDF
          </Button>

          <Button
            type="button"
            variant="outline"
            onClick={onReset}
            className="
              !h-7
              !min-h-0
              !rounded-md
              !border-slate-300
              !bg-white
              !px-3
              !py-0
              !text-xs
              !font-medium
              !leading-none
              !text-slate-700
              hover:!bg-slate-50
            "
          >
            New invoice
          </Button>
        </div>

        {/* RIGHT ACTIONS */}

        <div className="ml-auto flex items-center gap-2">
          <Button
            type="button"
            variant="outline"
            onClick={handleCancel}
            className="
              !h-7
              !min-h-0
              !rounded-md
              !border-slate-300
              !bg-white
              !px-3
              !py-0
              !text-xs
              !font-medium
              !leading-none
              !text-slate-700
              hover:!bg-slate-50
            "
          >
            Cancel
          </Button>

          <Button
            type="button"
            onClick={handleSubmit}
            className="
              !h-7
              !min-h-0
              !rounded-md
              !border-[#2F4F3E]
              !bg-[#2F4F3E]
              !px-3
              !py-0
              !text-xs
              !font-medium
              !leading-none
              !text-white
              hover:!bg-[#264334]
            "
          >
            Submit
          </Button>
        </div>
      </div>
    </section>
  );
}

/* =========================================================
   COMMON INPUT
   ALL CELLS = h-8
========================================================= */

const inputClass = `
  h-8
  w-full
  px-1.5
  py-0
  !text-[9px]
  font-normal
  leading-6
  text-slate-400
  placeholder:text-slate-300
`;

/* =========================================================
   SELECT
   ALL CELLS = h-8
========================================================= */

const selectClass = `
  h-8
  w-full
  rounded-md
  border
  border-slate-300
  bg-white
  px-1.5
  py-0
  !text-[9px]
  font-normal
  leading-6
  text-slate-400
  outline-none
  focus:border-slate-500
  focus:ring-1
  focus:ring-slate-500/10
`;

/* =========================================================
   SECTION TITLE
========================================================= */

function SectionTitle({
  title,
}: {
  title: string;
}) {
  return (
    <div
      className="
        absolute
        -top-3
        left-3
        z-10
        flex
        h-6
        w-auto
        items-center
        rounded-md
        border-l-2
        border-emerald-900
        bg-[#E8EFE9]
        px-3
      "
    >
      <span
        className="
          text-[10px]
          font-semibold
          tracking-[0.14em]
          text-slate-800
        "
      >
        {title}
      </span>
    </div>
  );
}

/* =========================================================
   FIELD
========================================================= */

function Field({
  label,
  children,
}: {
  label: string;
  children: ReactNode;
}) {
  return (
    <div className="min-w-0">
      <label
        className="
          mb-0.5
          block
          truncate
          text-[11px]
          font-semibold
          leading-4
          text-slate-700
        "
      >
        {label}
      </label>

      {children}
    </div>
  );
}