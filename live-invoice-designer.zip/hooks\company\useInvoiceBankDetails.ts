"use client";

import { useQuery } from "@tanstack/react-query";

import {
  GetInvoiceBankDetails,
} from "@/services/company/companyService";

export const useInvoiceBankDetails = (
  companyId: number | null,
) => {
  return useQuery({
    queryKey: [
      "invoiceBankDetails",
      companyId,
    ],

    queryFn: async () => {
      if (companyId === null) {
        throw new Error(
          "Company ID is required",
        );
      }

      const response =
        await GetInvoiceBankDetails(
          companyId,
        );

      return response.items;
    },

    enabled: companyId !== null,

    retry: false,
  });
};