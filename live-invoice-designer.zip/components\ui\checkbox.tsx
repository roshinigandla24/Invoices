import * as React from "react";
import { cn } from "@/lib/utils";

export const Checkbox = React.forwardRef<HTMLInputElement, React.InputHTMLAttributes<HTMLInputElement>>(
  ({ className, type, ...props }, ref) => (
    <input
      ref={ref}
      type="checkbox"
      className={cn("h-3.5 w-3.5 accent-blue-600", className)}
      {...props}
    />
  ),
);
Checkbox.displayName = "Checkbox";
