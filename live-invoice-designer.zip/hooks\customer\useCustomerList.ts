"use client";

import { useQuery } from "@tanstack/react-query";

import { GetCustomerDetails } from "@/services/company/companyService";

export const useCustomerList = (
  companyId: string,
) => {
  return useQuery({
    queryKey: ["customerList", companyId],

    queryFn: async () => {
      const response =
        await GetCustomerDetails(companyId);

      return response;
    },

    enabled: Boolean(companyId),

    staleTime: 60 * 1000,

    refetchOnWindowFocus: false,
  });
};