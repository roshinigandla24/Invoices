import CompanyTest from "@/components/api-test/company-test";

export default function ApiTestPage() {
  return (
    <main className="p-8">
      <CompanyTest />
    </main>
  );
}