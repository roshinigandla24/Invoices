"use client";

import { ChangeEvent, RefObject } from "react";
import type { InvoiceData, InvoiceItem } from "@/types/invoice";

import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
type Props = {
  invoice: InvoiceData;

  logoInputRef: RefObject<HTMLInputElement | null>;
  signatureInputRef: RefObject<HTMLInputElement | null>;

  updateField: <K extends keyof InvoiceData>(
    field: K,
    value: InvoiceData[K],
  ) => void;

  updateItem: (
    id: number,
    field: keyof InvoiceItem,
    value: string | number,
  ) => void;

  addItem: () => void;
  removeItem: (id: number) => void;

  handleImageUpload: (
    event: ChangeEvent<HTMLInputElement>,
    field: "logo" | "signature",
  ) => void;

  onPrint: () => void;
  onReset: () => void;
};

/* -------------------------------------------------------------------------- */
/* COMPACT FIELD STYLES                                                       */
/* -------------------------------------------------------------------------- */
const inputClass =
  "h-5 w-full px-1.5 py-0 text-left text-[9px] font-normal leading-5 text-slate-400 placeholder:text-slate-300";
const textareaClass =
  "h-5 min-h-5 w-full resize-none px-1.5 py-1 text-[9px] leading-3";
const smallTextareaClass =
  "h-5 min-h-5 w-full resize-none px-1.5 py-0 text-left text-[9px] font-normal leading-5 text-slate-400 placeholder:text-slate-300";
/* -------------------------------------------------------------------------- */
/* SECTION TITLE                                                              */
/* -------------------------------------------------------------------------- */

function SectionTitle({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div
      className="
        mb-1.5
        mt-2.5
        flex
        h-6
        w-full
        items-center
        rounded-md
        border-l-2
        border-emerald-900
        bg-[#E8EFE9]
        px-3
      "
    >
      <span
        className="
          text-[10px]
          font-semibold
          tracking-[0.14em]
          text-slate-800
        "
      >
        {children}
      </span>
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/* FIELD                                                                      */
/* -------------------------------------------------------------------------- */

function Field({
  label,
  children,
  className = "",
}: {
  label: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={`min-w-0 ${className}`}>
      <Label className="mb-0.5 block text-[9px] font-semibold leading-3 text-slate-700">
        {label}
      </Label>

      {children}
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/* PHONE FIELD                                                                */
/* -------------------------------------------------------------------------- */

function PhoneField({
  label,
  countryCode,
  phone,
  onCountryCodeChange,
  onPhoneChange,
}: {
  label: string;
  countryCode: string;
  phone: string;
  onCountryCodeChange: (value: string) => void;
  onPhoneChange: (value: string) => void;
}) {
  return (
    <Field label={label}>
      <div className="flex w-full min-w-0 gap-0.5">
        {/* Country code */}
        <div className="w-[58px] min-w-[58px] max-w-[58px] shrink-0">
          <select
            className="
              
              h-5
              w-full
              rounded-md
              border
              border-slate-300
              bg-white
              px-1.5
              py-0
              text-[9px]
              font-normal
              leading-none
              text-slate-400
              outline-none
              focus:border-blue-400
              focus:ring-1
              focus:ring-blue-400/20
            "
            style={{
              fontSize: "9px",
              fontFamily: "inherit",
              fontWeight: 400,
              color: "#94a3b8",
            }}
            value={countryCode}
            onChange={(e) => onCountryCodeChange(e.target.value)}
          >
            <option value="+91">+91</option>
            <option value="+1">+1</option>
            <option value="+44">+44</option>
            <option value="+61">+61</option>
            <option value="+65">+65</option>
            <option value="+971">+971</option>
            <option value="+966">+966</option>
          </select>
        </div>

        {/* Phone number - stores only the number */}
        <Input
          className="
            
            h-5
            min-w-0
            flex-1
            px-1.5
            py-0
            text-[9px]
            font-normal
            leading-none
            text-slate-400
            placeholder:text-slate-300
          "
          style={{
            fontSize: "9px",
            fontFamily: "inherit",
            fontWeight: 400,
            color: "#94a3b8",
          }}
          type="tel"
          inputMode="numeric"
          value={phone}
          onChange={(e) => {
            const value = e.target.value.replace(/\D/g, "");
            onPhoneChange(value);
          }}
          placeholder="Phone number"
        />
      </div>
    </Field>
  );
}

/* -------------------------------------------------------------------------- */
/* UPLOAD ICON                                                                */
/* -------------------------------------------------------------------------- */

function UploadIcon() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="22"
      height="22"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M12 16V4" />
      <path d="m7 9 5-5 5 5" />
      <path d="M5 20h14" />
    </svg>
  );
}

/* -------------------------------------------------------------------------- */
/* SIGNATURE ICON                                                             */
/* -------------------------------------------------------------------------- */

function SignatureIcon() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="22"
      height="22"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M12 20h9" />
      <path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L8 18l-4 1 1-4Z" />
    </svg>
  );
}

/* -------------------------------------------------------------------------- */
/* INVOICE FORM                                                               */
/* -------------------------------------------------------------------------- */

export function InvoiceForm({
  invoice,
  logoInputRef,
  signatureInputRef,
  updateField,
  updateItem,
  addItem,
  removeItem,
  handleImageUpload,
  onPrint,
  onReset,
}: Props) {
  /* -------------------------------------------------------------------------- */
  /* SUBMIT / CANCEL                                                            */
  /* Save the submitted Indian invoice in browser storage.                     */
  /* -------------------------------------------------------------------------- */

  const handleSubmit = () => {
    if (!invoice.invoiceNumber.trim()) {
      alert("Please enter an invoice number.");
      return;
    }

    const total = invoice.items.reduce(
      (sum, item) =>
        sum +
        Number(item.quantity || 0) *
          Number(item.amount || 0),
      0,
    );

    const submittedInvoice = {
      id: Date.now(),
      invoiceNumber: invoice.invoiceNumber,
      format: "Indian Invoice",
      businessName: invoice.businessName,
      customer:
        invoice.customerCompany?.trim() ||
        invoice.customerName,
      date: invoice.invoiceDate,
      dueDate: invoice.dueDate,
      paymentTerms: invoice.paymentTerms,
      currency: invoice.currency,
      amount: total,
      status: "Pending",
    };

    try {
      const existing = JSON.parse(
        localStorage.getItem("invoice-list-submitted") || "[]",
      );

      const records = Array.isArray(existing)
        ? existing
        : [];

      localStorage.setItem(
        "invoice-list-submitted",
        JSON.stringify([
          ...records,
          submittedInvoice,
        ]),
      );

      window.location.href = "/";
    } catch {
      alert("Unable to save the invoice.");
    }
  };

  const handleCancel = () => {
    window.location.href = "/";
  };

  return (
    <section className="relative flex h-full min-h-0 flex-col bg-white">
      <div className="min-h-0 flex-1 overflow-y-auto px-3 pt-0 pb-16">

        {/* ================================================================== */}
        {/* HEADER                                                             */}
        {/* ================================================================== */}

        <header className="shrink-0 border-b border-slate-200 bg-white px-0 pt-1 pb-1">
          <div className="h-8 w-full rounded-lg bg-[#2F4F3E] px-4 flex items-center">
            <h1 className="text-lg font-bold tracking-tight text-white">
              Indian Invoice
            </h1>
          </div>

          <p className="mt-0.5 text-[9px] text-slate-500">
            Fill in the details and see your invoice update instantly.
          </p>
        </header>

        {/* ================================================================== */}
        {/* BUSINESS DETAILS                                                   */}
        {/* ================================================================== */}

        <SectionTitle>
          BUSINESS DETAILS
        </SectionTitle>

        {/* ------------------------------------------------------------------ */}
        {/* LOGO UPLOAD                                                        */}
        {/* ------------------------------------------------------------------ */}

        <div className="mb-2">
          <button
            type="button"
            onClick={() =>
              logoInputRef.current?.click()
            }
            className="
              group
              relative
              flex
              h-[72px]
              w-[84px]
              cursor-pointer
              items-center
              justify-center
              overflow-hidden
              rounded-md
              border
              border-dashed
              border-slate-300
              bg-slate-50
              transition-all
              hover:border-blue-400
              hover:bg-blue-50/30
              focus:outline-none
              focus:ring-2
              focus:ring-blue-500/20
            "
          >
            {invoice.logo ? (
              <>
                <img
                  src={invoice.logo}
                  alt="Business logo"
                  className="
                    h-full
                    w-full
                    object-contain
                    p-1.5
                  "
                />

                <div
                  className="
                    absolute
                    inset-0
                    flex
                    items-center
                    justify-center
                    bg-slate-900/50
                    opacity-0
                    transition-opacity
                    group-hover:opacity-100
                  "
                >
                  <span
                    className="
                      rounded-md
                      bg-white
                      px-2
                      py-1
                      text-[9px]
                      font-medium
                      text-slate-700
                      shadow-sm
                    "
                  >
                    Replace
                  </span>
                </div>
              </>
            ) : (
              <div className="flex flex-col items-center justify-center">
                <div className="mb-1 text-slate-400 transition-colors group-hover:text-blue-500">
                  <UploadIcon />
                </div>

                <span className="text-[8px] font-medium text-slate-600 group-hover:text-blue-600">
                  Upload logo
                </span>
              </div>
            )}
          </button>

          <input
            ref={logoInputRef}
            type="file"
            accept="image/png,image/jpeg,image/webp"
            hidden
            onChange={(e) =>
              handleImageUpload(e, "logo")
            }
          />
        </div>

        {/* ------------------------------------------------------------------ */}
        {/* COMPANY / PHONE / EMAIL / WEBSITE                                  */}
        {/* ------------------------------------------------------------------ */}

        <div className="grid min-w-0 grid-cols-4 gap-1.5">
          <Field label="Business / company name">
            <Input
              className={inputClass}
              value={invoice.businessName}
              onChange={(e) => updateField("businessName", e.target.value)}
            />
          </Field>

          <PhoneField
            label="Phone"
            countryCode={invoice.phoneCountryCode}
            phone={invoice.phone}
            onCountryCodeChange={(value) =>
              updateField("phoneCountryCode", value)
            }
            onPhoneChange={(value) => updateField("phone", value)}
          />

          <Field label="Email">
            <Input
              className={inputClass}
              value={invoice.email}
              onChange={(e) => updateField("email", e.target.value)}
            />
          </Field>

          <Field label="Website">
            <Input
              className={inputClass}
              value={invoice.website}
              onChange={(e) => updateField("website", e.target.value)}
            />
          </Field>
        </div>

        {/* ------------------------------------------------------------------ */}
        {/* BUSINESS ADDRESS                                                   */}
        {/* ------------------------------------------------------------------ */}

        <div className="mt-1 grid grid-cols-4 gap-1.5">
          <Field label="House No. / Building">
            <Input
              className={inputClass}
              value={invoice.addressHouseNumber}
              onChange={(e) =>
                updateField("addressHouseNumber", e.target.value)
              }
            />
          </Field>

          <Field label="Street / Road">
            <Input
              className={inputClass}
              value={invoice.addressStreet}
              onChange={(e) => updateField("addressStreet", e.target.value)}
            />
          </Field>

          <Field label="City">
            <Input
              className={inputClass}
              value={invoice.addressCity}
              onChange={(e) => updateField("addressCity", e.target.value)}
            />
          </Field>

          <Field label="State">
            <Input
              className={inputClass}
              value={invoice.addressState}
              onChange={(e) => updateField("addressState", e.target.value)}
            />
          </Field>
        </div>

        <div className="mt-1 grid grid-cols-4 gap-1.5">
          <Field label="District">
            <Input
              className={inputClass}
              value={invoice.addressDistrict}
              onChange={(e) =>
                updateField("addressDistrict", e.target.value)
              }
            />
          </Field>

          <Field label="Country">
            <Input
              className={inputClass}
              value={invoice.addressCountry}
              onChange={(e) =>
                updateField("addressCountry", e.target.value)
              }
            />
          </Field>

          <Field label="Pincode">
            <Input
              className={inputClass}
              value={invoice.addressPincode}
              onChange={(e) =>
                updateField("addressPincode", e.target.value)
              }
            />
          </Field>

          <Field label="GST / VAT / Tax No.">
            <Input
              className={inputClass}
              value={invoice.gst}
              onChange={(e) => updateField("gst", e.target.value)}
            />
          </Field>
        </div>

        {/* ------------------------------------------------------------------ */}
        {/* BANK DETAILS                                                       */}
        {/* ------------------------------------------------------------------ */}

        <SectionTitle>
          BANK DETAILS
        </SectionTitle>

        <div className="grid min-w-0 grid-cols-4 gap-1.5">
          <Field label="Bank Name">
            <Input
              className={inputClass}
              value={invoice.bankName}
              onChange={(e) => updateField("bankName", e.target.value)}
            />
          </Field>

          <Field label="Account Number">
            <Input
              className={inputClass}
              value={invoice.bankAccountNumber}
              onChange={(e) =>
                updateField("bankAccountNumber", e.target.value)
              }
            />
          </Field>

          <Field label="IFSC Code">
            <Input
              className={inputClass}
              value={invoice.bankIfscCode}
              onChange={(e) => updateField("bankIfscCode", e.target.value)}
            />
          </Field>

          <Field label="UPI ID">
            <Input
              className={inputClass}
              value={invoice.bankUpiId}
              onChange={(e) => updateField("bankUpiId", e.target.value)}
            />
          </Field>
        </div>

        {/* ================================================================== */}
        {/* INVOICE DETAILS                                                    */}
        {/* ================================================================== */}

        <SectionTitle>
          INVOICE DETAILS
        </SectionTitle>

        <div className="grid grid-cols-3 gap-1.5">
          <Field label="Invoice number">
            <Input
              className={inputClass}
              value={invoice.invoiceNumber}
              onChange={(e) =>
                updateField(
                  "invoiceNumber",
                  e.target.value,
                )
              }
            />
          </Field>

          <Field label="Status">
            <Select
              className={inputClass}
              value={invoice.status}
              onChange={(e) =>
                updateField(
                  "status",
                  e.target.value,
                )
              }
            >
              <option value="Draft">
                Draft
              </option>

              <option value="Sent">
                Sent
              </option>

              <option value="Paid">
                Paid
              </option>

              <option value="Cancelled">
                Cancelled
              </option>
            </Select>
          </Field>

          <Field label="Invoice date">
            <Input
              type="date"
              className={inputClass}
              value={invoice.invoiceDate}
              onChange={(e) =>
                updateField(
                  "invoiceDate",
                  e.target.value,
                )
              }
            />
          </Field>
        </div>

        <div className="mt-1.5 grid grid-cols-3 gap-1.5">
          <Field label="Due date">
            <Input
              type="date"
              className={inputClass}
              value={invoice.dueDate}
              onChange={(e) =>
                updateField(
                  "dueDate",
                  e.target.value,
                )
              }
            />
          </Field>

          <Field label="Payment terms">
            <Select
              className={inputClass}
              value={invoice.paymentTerms}
              onChange={(e) =>
                updateField(
                  "paymentTerms",
                  e.target.value,
                )
              }
            >
              <option value="Due on receipt">
                Due on receipt
              </option>

              <option value="Net 7">
                Net 7
              </option>

              <option value="Net 15">
                Net 15
              </option>

              <option value="Net 30">
                Net 30
              </option>

              <option value="Net 60">
                Net 60
              </option>
            </Select>
          </Field>

          <Field label="Currency">
            <Select
              className={inputClass}
              value={invoice.currency}
              onChange={(e) =>
                updateField(
                  "currency",
                  e.target.value,
                )
              }
            >
              <option value="₹ INR">
                ₹ INR
              </option>

              <option value="$ USD">
                $ USD
              </option>

              <option value="€ EUR">
                € EUR
              </option>

              <option value="£ GBP">
                £ GBP
              </option>

              <option value="¥ JPY">
                ¥ JPY
              </option>

              <option value="C$ CAD">
                C$ CAD
              </option>

              <option value="A$ AUD">
                A$ AUD
              </option>

              <option value="CHF CHF">
                CHF CHF
              </option>

              <option value="د.إ AED">
                د.إ AED
              </option>

              <option value="﷼ SAR">
                ﷼ SAR
              </option>
            </Select>
          </Field>
        </div>

        {/* ------------------------------------------------------------------ */}
        {/* INTERSTATE                                                         */}
        {/* ------------------------------------------------------------------ */}

        <label className="mt-1.5 flex items-center gap-1.5 text-[9px] text-slate-600">
          <Checkbox
            checked={invoice.interState}
            onChange={(e) =>
              updateField(
                "interState",
                e.target.checked,
              )
            }
          />

          Interstate transaction
          (apply IGST instead of CGST + SGST)
        </label>

               {/* ================================================================== */}
        {/* CUSTOMER / BILL TO                                                 */}
        {/* ================================================================== */}

        <SectionTitle>
          CUSTOMER / BILL TO
        </SectionTitle>

        {/* ------------------------------------------------------------------ */}
        {/* CUSTOMER BASIC DETAILS                                             */}
        {/* ------------------------------------------------------------------ */}

        <div className="grid min-w-0 grid-cols-4 gap-1.5">
          <Field label="Customer name">
            <Input
              className={inputClass}
              value={invoice.customerName}
              onChange={(e) =>
                updateField("customerName", e.target.value)
              }
            />
          </Field>

          <Field label="Company name">
            <Input
              className={inputClass}
              value={invoice.customerCompany}
              onChange={(e) =>
                updateField("customerCompany", e.target.value)
              }
            />
          </Field>

          <PhoneField
            label="Phone"
            countryCode={invoice.customerPhoneCountryCode}
            phone={invoice.customerPhone}
            onCountryCodeChange={(value) =>
              updateField("customerPhoneCountryCode", value)
            }
            onPhoneChange={(value) => updateField("customerPhone", value)}
          />

          <Field label="Email">
            <Input
              className={inputClass}
              value={invoice.customerEmail}
              onChange={(e) =>
                updateField("customerEmail", e.target.value)
              }
            />
          </Field>
        </div>

        {/* ------------------------------------------------------------------ */}
        {/* CUSTOMER ADDRESS                                                   */}
        {/* ------------------------------------------------------------------ */}

        <div className="mt-1 grid grid-cols-4 gap-1.5">
          <Field label="House No. / Building">
            <Input
              className={inputClass}
              value={invoice.customerHouseNumber}
              onChange={(e) =>
                updateField("customerHouseNumber", e.target.value)
              }
            />
          </Field>

          <Field label="Street / Road">
            <Input
              className={inputClass}
              value={invoice.customerStreet}
              onChange={(e) =>
                updateField("customerStreet", e.target.value)
              }
            />
          </Field>

          <Field label="City">
            <Input
              className={inputClass}
              value={invoice.customerCity}
              onChange={(e) =>
                updateField("customerCity", e.target.value)
              }
            />
          </Field>

          <Field label="State">
            <Input
              className={inputClass}
              value={invoice.customerState}
              onChange={(e) =>
                updateField("customerState", e.target.value)
              }
            />
          </Field>
        </div>

        <div className="mt-1 grid grid-cols-4 gap-1.5">
          <Field label="District">
            <Input
              className={inputClass}
              value={invoice.customerDistrict}
              onChange={(e) =>
                updateField("customerDistrict", e.target.value)
              }
            />
          </Field>

          <Field label="Country">
            <Input
              className={inputClass}
              value={invoice.customerCountry}
              onChange={(e) =>
                updateField("customerCountry", e.target.value)
              }
            />
          </Field>

          <Field label="Pincode">
            <Input
              className={inputClass}
              value={invoice.customerPincode}
              onChange={(e) =>
                updateField("customerPincode", e.target.value)
              }
            />
          </Field>

          <Field label="GST / VAT / Tax No.">
            <Input
              className={inputClass}
              placeholder="Optional"
              value={invoice.customerGst}
              onChange={(e) =>
                updateField("customerGst", e.target.value)
              }
            />
          </Field>
        </div>

        {/* ------------------------------------------------------------------ */}
        {/* SHIPPING                                                           */}
        {/* ------------------------------------------------------------------ */}

        <label className="mt-1.5 flex items-center gap-1.5 text-[9px] text-slate-600">
          <Checkbox
            checked={invoice.shippingSameAsBilling}
            onChange={(e) =>
              updateField("shippingSameAsBilling", e.target.checked)
            }
          />

          Shipping address same as billing
        </label>

        {!invoice.shippingSameAsBilling && (
          <>
            <div className="mt-1 grid grid-cols-4 gap-1.5">
              <Field label="House No. / Building">
                <Input
                  className={inputClass}
                  value={invoice.shippingHouseNumber}
                  onChange={(e) =>
                    updateField("shippingHouseNumber", e.target.value)
                  }
                />
              </Field>

              <Field label="Street / Road">
                <Input
                  className={inputClass}
                  value={invoice.shippingStreet}
                  onChange={(e) =>
                    updateField("shippingStreet", e.target.value)
                  }
                />
              </Field>

              <Field label="City">
                <Input
                  className={inputClass}
                  value={invoice.shippingCity}
                  onChange={(e) =>
                    updateField("shippingCity", e.target.value)
                  }
                />
              </Field>

              <Field label="State">
                <Input
                  className={inputClass}
                  value={invoice.shippingState}
                  onChange={(e) =>
                    updateField("shippingState", e.target.value)
                  }
                />
              </Field>
            </div>

            <div className="mt-1 grid grid-cols-4 gap-1.5">
              <Field label="District">
                <Input
                  className={inputClass}
                  value={invoice.shippingDistrict}
                  onChange={(e) =>
                    updateField("shippingDistrict", e.target.value)
                  }
                />
              </Field>

              <Field label="Country">
                <Input
                  className={inputClass}
                  value={invoice.shippingCountry}
                  onChange={(e) =>
                    updateField("shippingCountry", e.target.value)
                  }
                />
              </Field>

              <Field label="Pincode">
                <Input
                  className={inputClass}
                  value={invoice.shippingPincode}
                  onChange={(e) =>
                    updateField("shippingPincode", e.target.value)
                  }
                />
              </Field>

              <PhoneField
                label="Phone"
                countryCode={invoice.shippingPhoneCountryCode}
                phone={invoice.shippingPhone}
                onCountryCodeChange={(value) =>
                  updateField("shippingPhoneCountryCode", value)
                }
                onPhoneChange={(value) =>
                  updateField("shippingPhone", value)
                }
              />
            </div>

            <div className="mt-1 grid grid-cols-4 gap-1.5">
              <Field label="GST / VAT / Tax No.">
                <Input
                  className={inputClass}
                  placeholder="Optional"
                  value={invoice.shippingGst}
                  onChange={(e) =>
                    updateField("shippingGst", e.target.value)
                  }
                />
              </Field>
            </div>
          </>
        )}

        {/* ================================================================== */}
        {/* ITEMS / PRODUCTS                                                   */}
        {/* ================================================================== */}

        <SectionTitle>
          ITEMS / PRODUCTS
        </SectionTitle>

        <div className="space-y-1.5">
          {invoice.items.map(
            (item, index) => (
              <div
                key={item.id}
                className="
                  rounded-md
                  border
                  border-slate-200
                  bg-slate-50/50
                  p-2
                "
              >
                <div className="mb-1.5 flex items-center justify-between">
  <span className="text-[9px] font-semibold text-slate-700">
    Item {index + 1}
  </span>

  <div className="flex items-center gap-1">
    {/* Add item */}
    <button
      type="button"
      onClick={addItem}
      className="
        flex
        h-6
        w-6
        shrink-0
        items-center
        justify-center
        rounded-md
        border
        border-[#009F6B]
        bg-transparent
        p-0
        text-[14px]
        font-medium
        leading-none
        text-[#009F6B]
        transition-colors
        hover:bg-[#009F6B]
        hover:text-white
      "
      aria-label="Add item"
    >
      +
    </button>

    {/* Delete item */}
    {invoice.items.length > 1 && (
      <button
        type="button"
        onClick={() => removeItem(item.id)}
        className="
          flex
          h-6
          w-6
          shrink-0
          items-center
          justify-center
          rounded-md
          border
          border-red-400
          bg-transparent
          p-0
          text-red-400
          transition-colors
          hover:bg-red-400
          hover:text-white
        "
        aria-label="Delete item"
      >
        <svg
          width="14"
          height="14"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="M3 6h18" />
          <path d="M8 6V4h8v2" />
          <path d="M19 6l-1 14H6L5 6" />
          <path d="M10 11v5" />
          <path d="M14 11v5" />
        </svg>
      </button>
    )}
  </div>
</div>
<div className="grid min-w-0 grid-cols-[30%_minmax(0,1fr)] gap-1.5">
  <Field label="Item / service name">
    <Input
      className={inputClass}
      value={item.name}
      onChange={(e) =>
        updateItem(item.id, "name", e.target.value)
      }
      placeholder="Item / service name"
    />
  </Field>

  <Field label="Description">
    <Input
      className={inputClass}
      value={item.description}
      onChange={(e) =>
        updateItem(
          item.id,
          "description",
          e.target.value,
        )
      }
      placeholder="Description"
    />
  </Field>
</div>
                <div className="mt-1.5 grid grid-cols-3 gap-2">
                  <Field label="SKU / Item code">
                    <Input
                      className={inputClass}
                      value={item.sku}
                      onChange={(e) =>
                        updateItem(
                          item.id,
                          "sku",
                          e.target.value,
                        )
                      }
                    />
                  </Field>

                  <Field label="Unit">
                    <Input
                      className={inputClass}
                      value={item.unit}
                      onChange={(e) =>
                        updateItem(
                          item.id,
                          "unit",
                          e.target.value,
                        )
                      }
                    />
                  </Field>

                  <Field label="Quantity">
                    <Input
                      className={inputClass}
                      type="number"
                      min={0}
                      value={item.quantity}
                      onChange={(e) =>
                        updateItem(
                          item.id,
                          "quantity",
                          Number(
                            e.target.value,
                          ),
                        )
                      }
                    />
                  </Field>
                </div>

                <div className="mt-1.5 grid grid-cols-3 gap-2">
                  <Field label="Unit price">
                    <Input
                      className={inputClass}
                      type="number"
                      min={0}
                      value={item.unitPrice}
                      onChange={(e) =>
                        updateItem(
                          item.id,
                          "unitPrice",
                          Number(
                            e.target.value,
                          ),
                        )
                      }
                    />
                  </Field>

                  <Field label="Discount %">
                    <Input
                      className={inputClass}
                      type="number"
                      min={0}
                      value={item.discount}
                      onChange={(e) =>
                        updateItem(
                          item.id,
                          "discount",
                          Number(
                            e.target.value,
                          ),
                        )
                      }
                    />
                  </Field>

                  <Field label="Tax %">
                    <Input
                      className={inputClass}
                      type="number"
                      min={0}
                      value={item.tax}
                      onChange={(e) =>
                        updateItem(
                          item.id,
                          "tax",
                          Number(
                            e.target.value,
                          ),
                        )
                      }
                    />
                  </Field>
                </div>
              </div>
            ),
          )}
        </div>

        {/* ================================================================== */}
        {/* OTHER CHARGES & PAYMENT                                           */}
        {/* ================================================================== */}

        <SectionTitle>
          OTHER CHARGES & PAYMENT
        </SectionTitle>

        <div className="grid grid-cols-2 gap-2">
          <Field label="Other charges (shipping, etc.)">
            <Input
              className={inputClass}
              type="number"
              min={0}
              value={invoice.otherCharges}
              onChange={(e) =>
                updateField(
                  "otherCharges",
                  Number(e.target.value),
                )
              }
            />
          </Field>

          <Field label="Amount paid">
            <Input
              className={inputClass}
              type="number"
              min={0}
              value={invoice.amountPaid}
              onChange={(e) =>
                updateField(
                  "amountPaid",
                  Number(e.target.value),
                )
              }
            />
          </Field>
        </div>

        <label className="mt-1.5 flex items-center gap-1.5 text-[9px] text-slate-600">
          <Checkbox
            checked={invoice.roundOff}
            onChange={(e) =>
              updateField(
                "roundOff",
                e.target.checked,
              )
            }
          />

          Round off grand total
        </label>

        {/* ================================================================== */}
        {/* ADDITIONAL INFORMATION                                             */}
        {/* ================================================================== */}

        <SectionTitle>
          ADDITIONAL INFORMATION
        </SectionTitle>

        <div className="flex w-full flex-col justify-center">
          <Field label="Notes">
            <Textarea
              className={smallTextareaClass}
              value={invoice.notes}
              onChange={(e) =>
                updateField(
                  "notes",
                  e.target.value,
                )
              }
            />
          </Field>

          <Field
            label="Terms & conditions"
            className="mt-1.5"
          >
            <Textarea
              className={smallTextareaClass}
              value={invoice.terms}
              onChange={(e) =>
                updateField(
                  "terms",
                  e.target.value,
                )
              }
            />
          </Field>

          <Field
            label="Payment instructions"
            className="mt-1.5"
          >
            <Textarea
              className={smallTextareaClass}
              value={invoice.paymentInstructions}
              onChange={(e) =>
                updateField(
                  "paymentInstructions",
                  e.target.value,
                )
              }
            />
          </Field>
        </div>

        {/* ================================================================== */}
        {/* SIGNATURE                                                          */}
        {/* ================================================================== */}

        <div className="mt-2">
          <label
            className="flex items-center gap-1.5 text-[10px] font-medium text-slate-700"
          >
            <Checkbox
              checked={invoice.requireSignature}
              onChange={(e) =>
                updateField(
                  "requireSignature",
                  e.target.checked,
                )
              }
            />

            <span>
              Require customer signature
            </span>
          </label>

          {/* ================================================================ */}
          {/* SIGNATURE UPLOAD ONLY WHEN CHECKED                              */}
          {/* ================================================================ */}

          {invoice.requireSignature && (
            <div className="mt-1.5 flex items-center gap-2">
              <button
                type="button"
                onClick={() =>
                  signatureInputRef.current?.click()
                }
                className="
                  group
                  relative
                  flex
                  h-[72px]
                  w-[84px]
                  shrink-0
                  cursor-pointer
                  items-center
                  justify-center
                  overflow-hidden
                  rounded-md
                  border
                  border-dashed
                  border-slate-300
                  bg-slate-50
                  transition-all
                  hover:border-blue-400
                  hover:bg-blue-50/30
                  focus:outline-none
                  focus:ring-2
                  focus:ring-blue-500/20
                "
              >
                {invoice.signature ? (
                  <>
                    <img
                      src={invoice.signature}
                      alt="Customer signature"
                      className="
                        h-full
                        w-full
                        object-contain
                        p-1.5
                      "
                    />

                    <div
                      className="
                        absolute
                        inset-0
                        flex
                        items-center
                        justify-center
                        bg-slate-900/50
                        opacity-0
                        transition-opacity
                        group-hover:opacity-100
                      "
                    >
                      <span
                        className="
                          rounded-md
                          bg-white
                          px-2
                          py-1
                          text-[9px]
                          font-medium
                          text-slate-700
                          shadow-sm
                        "
                      >
                        Replace
                      </span>
                    </div>
                  </>
                ) : (
                  <div className="flex flex-col items-center justify-center">
                    <div className="mb-1 text-slate-400 transition-colors group-hover:text-blue-500">
                      <SignatureIcon />
                    </div>

                    <span className="text-[9px] font-medium text-slate-600 group-hover:text-blue-600">
                      Upload signature
                    </span>
                  </div>
                )}
              </button>

              <input
                ref={signatureInputRef}
                type="file"
                accept="image/png,image/jpeg,image/webp"
                hidden
                onChange={(e) =>
                  handleImageUpload(
                    e,
                    "signature",
                  )
                }
              />
            </div>
          )}
        </div>
             </div>

      {/* =================================================
          BOTTOM ACTION BAR
          PRINT + NEW INVOICE ON LEFT
          CANCEL + SUBMIT ON RIGHT
      ================================================= */}

      <div
        className="
          absolute
          bottom-0
          left-0
          right-0
          z-20
          flex
          items-center
          border-t
          border-slate-200
          bg-white
          px-3
          py-2
        "
      >
        {/* LEFT ACTIONS */}
        <div className="flex items-center gap-2">
          <Button
            type="button"
            onClick={onPrint}
            className="
              !h-7
              !min-h-0
              !rounded-md
              !border-[#2F4F3E]
              !bg-[#2F4F3E]
              !px-3
              !py-0
              !text-xs
              !font-medium
              !leading-none
              !text-white
              hover:!bg-[#264334]
            "
          >
            🖨 Print / Save as PDF
          </Button>

          <Button
            type="button"
            variant="outline"
            onClick={onReset}
            className="
              !h-7
              !min-h-0
              !rounded-md
              !border-slate-300
              !bg-white
              !px-3
              !py-0
              !text-xs
              !font-medium
              !leading-none
              !text-slate-700
              hover:!bg-slate-50
            "
          >
            New invoice
          </Button>
        </div>

        {/* RIGHT ACTIONS: CANCEL FIRST, SUBMIT SECOND */}
        <div className="ml-auto flex items-center gap-2">
          <Button
            type="button"
            variant="outline"
            onClick={handleCancel}
            className="
              !h-7
              !min-h-0
              !rounded-md
              !border-slate-300
              !bg-white
              !px-3
              !py-0
              !text-xs
              !font-medium
              !leading-none
              !text-slate-700
              hover:!bg-slate-50
            "
          >
            Cancel
          </Button>

          <Button
            type="button"
            onClick={handleSubmit}
            className="
              !h-7
              !min-h-0
              !rounded-md
              !border-[#2F4F3E]
              !bg-[#2F4F3E]
              !px-3
              !py-0
              !text-xs
              !font-medium
              !leading-none
              !text-white
              hover:!bg-[#264334]
            "
          >
            Submit
          </Button>
        </div>
      </div>

    </section>
  );
}
