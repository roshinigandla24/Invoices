import * as React from "react";
import { cn } from "@/lib/utils";

export const Textarea = React.forwardRef<
  HTMLTextAreaElement,
  React.TextareaHTMLAttributes<HTMLTextAreaElement>
>(({ className, ...props }, ref) => (
  <textarea
    ref={ref}
    className={cn(
      "w-full h-8 min-h-8 max-h-8",
      "resize-none",
      "rounded-md border border-slate-300",
      "bg-white",
      "px-2 py-1",
      "!text-[10px] !leading-4",
      "font-normal text-slate-900",
      "outline-none",
      "focus:border-blue-500",
      "focus:ring-2 focus:ring-blue-500/10",
      "placeholder:text-slate-400",
      className,
    )}
    {...props}
  />
));

Textarea.displayName = "Textarea";