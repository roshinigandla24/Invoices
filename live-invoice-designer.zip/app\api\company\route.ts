import { NextResponse } from "next/server";

const BASE_URL =
  process.env.AKRA_API_BASE_URL ||
  "https://akra-common-api.onrender.com";

export async function POST(request: Request) {
  try {
    /* ============================================================
       GET REFRESH TOKEN
       ============================================================ */

    const refreshToken =
      process.env.AKRA_REFRESH_TOKEN;

    if (!refreshToken) {
      return NextResponse.json(
        {
          success: false,
          message:
            "AKRA_REFRESH_TOKEN is not configured",
        },
        { status: 500 },
      );
    }

    /* ============================================================
       GET REQUEST FROM FRONTEND
       ============================================================ */

    const requestBody =
      await request.json();

    const requestParamType =
      requestBody?.RequestParamType;

    const json =
      requestBody?.json;

    if (!requestParamType) {
      return NextResponse.json(
        {
          success: false,
          message:
            "RequestParamType is required",
        },
        { status: 400 },
      );
    }

    /* ============================================================
       STEP 1 — REFRESH ACCESS TOKEN
       ============================================================ */

    const refreshResponse =
      await fetch(
        `${BASE_URL}/auth/refresh-token`,
        {
          method: "POST",

          headers: {
            "Content-Type":
              "application/json",

            /*
              Your AKRA API requires Origin.
              Your Next.js application is running
              on port 3000.
            */
            Origin:
              "http://localhost:3000",
          },

          body: JSON.stringify({
            refreshToken,
          }),

          cache: "no-store",
        },
      );

    const refreshData =
      await refreshResponse.json();

    if (!refreshResponse.ok) {
      console.error(
        "Refresh Token API Error:",
        refreshData,
      );

      return NextResponse.json(
        refreshData,
        {
          status:
            refreshResponse.status,
        },
      );
    }

    /* ============================================================
       GET NEW ACCESS TOKEN
       ============================================================ */

    const accessToken =
      refreshData?.data?.accessToken ??
      refreshData?.accessToken;

    if (!accessToken) {
      return NextResponse.json(
        {
          success: false,
          message:
            "Access token was not returned by refresh API",
        },
        { status: 500 },
      );
    }

    /* ============================================================
       STEP 2 — BUILD AKRA REQUEST
       ============================================================ */

    const apiPayload: Record<
      string,
      unknown
    > = {
      RequestParamType:
        requestParamType,
    };

    /*
      For GetInvoiceBankDetails:

      {
        RequestParamType:
          "GetInvoiceBankDetails",

        json:
          "{\"CompanyID\":4}"
      }

      For GetCompanyList:

      {
        RequestParamType:
          "GetCompanyList"
      }
    */

    if (json !== undefined) {
      apiPayload.json = json;
    }

    console.log(
      "AKRA Request:",
      apiPayload,
    );

    /* ============================================================
       STEP 3 — CALL AKRA API
       ============================================================ */

    const apiResponse =
      await fetch(
        `${BASE_URL}/api/get-data`,
        {
          method: "POST",

          headers: {
            "Content-Type":
              "application/json",

            Origin:
              "http://localhost:3000",

            Authorization:
              `Bearer ${accessToken}`,
          },

          body: JSON.stringify(
            apiPayload,
          ),

          cache: "no-store",
        },
      );

    const apiData =
      await apiResponse.json();

    /* ============================================================
       AKRA API ERROR
       ============================================================ */

    if (!apiResponse.ok) {
      console.error(
        "AKRA API Error:",
        apiData,
      );

      return NextResponse.json(
        apiData,
        {
          status:
            apiResponse.status,
        },
      );
    }

    /* ============================================================
       SUCCESS
       ============================================================ */

    return NextResponse.json(
      apiData,
      {
        status: 200,
      },
    );
  } catch (error) {
    console.error(
      "Company API Route Error:",
      error,
    );

    return NextResponse.json(
      {
        success: false,
        message:
          "Internal server error",
      },
      { status: 500 },
    );
  }
}