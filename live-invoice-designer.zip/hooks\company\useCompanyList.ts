"use client";

import { useQuery } from "@tanstack/react-query";

import { GetCompanyList } from "@/services/company/companyService";

export const useCompanyList = () =>
  useQuery({
    queryKey: ["companyList"],

    queryFn: async () => {
      const response = await GetCompanyList();

      return response;
    },
  });