import type { InvoiceData } from "@/types/invoice";

export function formatCurrency(value: number, currency = "₹") {
  return `${currency}${value.toLocaleString("en-IN", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
}

export function numberToWords(num: number): string {
  if (num === 0) return "Zero";

  const ones = ["", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"];
  const tens = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"];

  const belowThousand = (n: number): string => {
    let result = "";
    if (n >= 100) {
      result += `${ones[Math.floor(n / 100)]} Hundred `;
      n %= 100;
    }
    if (n >= 20) {
      result += `${tens[Math.floor(n / 10)]} `;
      n %= 10;
    }
    if (n > 0) result += `${ones[n]} `;
    return result.trim();
  };

  let result = "";
  if (num >= 10000000) {
    result += `${belowThousand(Math.floor(num / 10000000))} Crore `;
    num %= 10000000;
  }
  if (num >= 100000) {
    result += `${belowThousand(Math.floor(num / 100000))} Lakh `;
    num %= 100000;
  }
  if (num >= 1000) {
    result += `${belowThousand(Math.floor(num / 1000))} Thousand `;
    num %= 1000;
  }
  if (num > 0) result += belowThousand(num);
  return result.trim();
}

export function calculateInvoice(invoice: InvoiceData) {
  let subtotal = 0;
  let totalDiscount = 0;
  let taxableAmount = 0;
  let cgst = 0;
  let sgst = 0;
  let igst = 0;

  const calculatedItems = invoice.items.map((item) => {
    const base = item.quantity * item.unitPrice;
    const discountAmount = base * (item.discount / 100);
    const taxable = base - discountAmount;
    const taxAmount = taxable * (item.tax / 100);

    subtotal += base;
    totalDiscount += discountAmount;
    taxableAmount += taxable;

    if (invoice.interState) igst += taxAmount;
    else {
      cgst += taxAmount / 2;
      sgst += taxAmount / 2;
    }

    return {
      ...item,
      base,
      discountAmount,
      taxable,
      taxAmount,
      lineTotal: taxable + taxAmount,
    };
  });

  const totalTax = cgst + sgst + igst;
  const beforeRound = taxableAmount + totalTax + Number(invoice.otherCharges || 0);
  const roundedTotal = invoice.roundOff ? Math.round(beforeRound) : beforeRound;
  const roundOffAmount = roundedTotal - beforeRound;
  const balanceDue = roundedTotal - Number(invoice.amountPaid || 0);

  return {
    calculatedItems,
    subtotal,
    totalDiscount,
    taxableAmount,
    cgst,
    sgst,
    igst,
    totalTax,
    beforeRound,
    roundedTotal,
    roundOffAmount,
    balanceDue,
  };
}
