"use client";

import { useQuery } from "@tanstack/react-query";
import { GetInvoices } from "@/services/company/companyService";

export const useInvoice = (invoiceId: string) => {
  return useQuery({
    queryKey: ["invoice", invoiceId],
    queryFn: () => GetInvoices(invoiceId),
    enabled: Boolean(invoiceId),
    staleTime: 60 * 1000,
    refetchOnWindowFocus: false,
  });
};