"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import type { InvoiceData } from "@/types/invoice";
import { numberToWords } from "@/lib/invoice-utils";

export type Calculations =
  ReturnType<typeof import("@/lib/invoice-utils").calculateInvoice>;

type Props = {
  invoice: InvoiceData;
  calculations: Calculations;
};

/* -------------------------------------------------------------------------- */
/* Invoice Preview                                                            */
/* -------------------------------------------------------------------------- */

export function InvoicePreview({
  invoice,
  calculations,
}: Props) {
  const viewportRef = useRef<HTMLDivElement>(null);

  /* ------------------------------------------------------------------------ */
  /* Currency display                                                         */
  /* ------------------------------------------------------------------------ */

  const currencyMap: Record<string, string> = {
    "₹ INR": "INR",
    "$ USD": "USD",
    "€ EUR": "EUR",
    "£ GBP": "GBP",
    "¥ JPY": "JPY",
    "C$ CAD": "CAD",
    "A$ AUD": "AUD",
    "CHF CHF": "CHF",
    "د.إ AED": "AED",
    "﷼ SAR": "SAR",
  };

  const selectedCurrency =
    currencyMap[invoice.currency] ?? "INR";

  const displayCurrency = (amount: number) => {
    const fractionDigits =
      selectedCurrency === "JPY" ? 0 : 2;

    const symbols: Record<string, string> = {
      INR: "₹",
      USD: "$",
      EUR: "€",
      GBP: "£",
      JPY: "¥",
      CAD: "C$",
      AUD: "A$",
      CHF: "CHF ",
      AED: "د.إ ",
      SAR: "﷼ ",
    };

    const symbol =
      symbols[selectedCurrency] ?? `${selectedCurrency} `;

    return `${amount < 0 ? "-" : ""}${symbol}${Math.abs(amount).toLocaleString("en-IN", {
      minimumFractionDigits: fractionDigits,
      maximumFractionDigits: fractionDigits,
    })}`;
  };

  /*
   * 1 = 100%
   * 0.8 = 80%
   * 1.2 = 120%
   */
  const [zoom, setZoom] = useState(0.57);

  /* ------------------------------------------------------------------------ */
  /* Calculate the zoom required to completely fit A4 inside the viewport    */
  /* ------------------------------------------------------------------------ */

  const calculateFitZoom = useCallback(() => {
    const viewport = viewportRef.current;

    if (!viewport) {
      return 0.8;
    }

    /*
     * A4:
     *
     * Width  = 210mm
     * Height = 297mm
     *
     * We use pixels only for the calculation.
     * The actual invoice remains physically A4 sized.
     */

    const A4_WIDTH_PX = 794;
    const A4_HEIGHT_PX = 1123;

    const padding = 32;

    const availableWidth =
      Math.max(viewport.clientWidth - padding, 200);

    const availableHeight =
      Math.max(viewport.clientHeight - padding, 200);

    const widthScale =
      availableWidth / A4_WIDTH_PX;

    const heightScale =
      availableHeight / A4_HEIGHT_PX;

    const fitScale =
      Math.min(widthScale, heightScale);

    /*
     * Never automatically make the invoice larger than 100%.
     */
   return Math.max(0.57, Math.min(fitScale, 1));
  }, []);

  /* ------------------------------------------------------------------------ */
  /* Initial fit                                                              */
  /* ------------------------------------------------------------------------ */

  useEffect(() => {
    const updateFit = () => {
      setZoom(calculateFitZoom());
    };

    updateFit();

    window.addEventListener("resize", updateFit);

    return () => {
      window.removeEventListener("resize", updateFit);
    };
  }, [calculateFitZoom]);

  /* ------------------------------------------------------------------------ */
  /* Zoom controls                                                            */
  /* ------------------------------------------------------------------------ */

  const zoomIn = () => {
    setZoom((current) =>
      Math.min(
        Number((current + 0.1).toFixed(2)),
        2,
      ),
    );
  };

  const zoomOut = () => {
    setZoom((current) =>
      Math.max(
        Number((current - 0.1).toFixed(2)),
        0.4,
      ),
    );
  };

  const fitToPage = () => {
    setZoom(calculateFitZoom());
  };

  /* ------------------------------------------------------------------------ */
  /* Render                                                                   */
  /* ------------------------------------------------------------------------ */

  return (
    <section
      className="
        flex
        h-full
        min-h-0
        min-w-0
        flex-col
        bg-slate-100/80
      "
    >
      {/* ================================================================== */}
      {/* PREVIEW HEADER                                                     */}
      {/* ================================================================== */}

      <header
        className="
          flex
          h-[45px]
          shrink-0
          items-center
          justify-between
          border-b
          border-slate-200
          bg-slate-100
          px-5
        "
      >
        <div>
          <h2 className="text-base font-semibold text-slate-900">
            Live Invoice
          </h2>

          <p className="text-[11px] text-slate-500 font-medium">
            Updates instantly while editing
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* ============================================================ */}
          {/* ZOOM CONTROL                                                 */}
          {/* ============================================================ */}

          <div
            className="
              flex
              h-8
              overflow-hidden
              rounded-md
              border
              border-slate-300
              bg-white
            "
          >
            {/* Zoom out */}

            <button
              type="button"
              onClick={zoomOut}
              className="
                flex
                h-full
                w-8
                items-center
                justify-center
                text-sm
                text-slate-700
                transition
                hover:bg-slate-100
              "
              aria-label="Zoom out"
            >
              −
            </button>

            {/* Current zoom / Fit */}

            <button
              type="button"
              onClick={fitToPage}
              className="
                min-w-[58px]
                border-x
                border-slate-200
                px-2
                text-[10px]
                font-medium
                text-slate-500 font-medium
                transition
                hover:bg-slate-50
              "
              title="Fit invoice to page"
            >
              {Math.round(zoom * 100)}%
            </button>

            {/* Zoom in */}

            <button
              type="button"
              onClick={zoomIn}
              className="
                flex
                h-full
                w-8
                items-center
                justify-center
                text-sm
                text-slate-700
                transition
                hover:bg-slate-100
              "
              aria-label="Zoom in"
            >
              +
            </button>
          </div>

          {/* LIVE */}

          <span
            className="
              rounded-full
              bg-emerald-100
              px-3
              py-1.5
              text-[10px]
              font-semibold
              text-emerald-700
            "
          >
            ● LIVE
          </span>
        </div>
      </header>

      {/* ================================================================== */}
      {/* INVOICE VIEWPORT                                                   */}
      {/* ================================================================== */}

      <div
        ref={viewportRef}
        className="
          min-h-0
          min-w-0
          flex-1
          overflow-auto
          bg-slate-100
          p-4
        "
      >
        {/* ================================================================ */}
        {/* SCROLL AREA                                                      */}
        {/* ================================================================ */}

        <div
          className="
            flex
            min-h-full
            min-w-full
            items-center
            justify-center
          "
        >
          {/* ============================================================ */}
          {/* SCALED A4 WRAPPER                                             */}
          {/* ============================================================ */}

          <div
            className="relative shrink-0"
            style={{
              /*
               * The wrapper itself receives the scaled dimensions.
               *
               * This is important:
               *
               * transform: scale()
               *
               * alone does NOT affect normal document flow.
               *
               * By changing the wrapper dimensions too,
               * the browser knows the actual scrollable area.
               */

              width: `${794 * zoom}px`,
              height: `${1123 * zoom}px`,
            }}
          >
            {/* ========================================================== */}
            {/* A4 INVOICE                                                  */}
            {/* ========================================================== */}

            <article
              className="
                invoice-paper
                absolute
                left-0
                top-0

                h-[297mm]
                w-[210mm]

                origin-top-left

                overflow-hidden

                bg-white

                p-[9mm]

                shadow-[0_4px_20px_rgba(15,23,42,0.08)]

              "
              style={{
                transform: `scale(${zoom})`,
              }}
            >
              {/* ======================================================== */}
              {/* HEADER                                                    */}
              {/* ======================================================== */}

              <div
                className="
                  flex
                  items-start
                  justify-between
                  gap-6
                  border-b
                  border-slate-900
                  pb-3
                "
              >
                {/* BUSINESS INFORMATION */}
                <div className="min-w-0 flex-1">
                  <div
                    className="
                      mb-1.5
                      flex
                      h-9
                      w-14
                      items-center
                      justify-start
                      overflow-hidden
                    "
                  >
                    {invoice.logo ? (
                      <img
                        src={invoice.logo}
                        alt="Logo"
                        className="max-h-full max-w-full object-contain"
                      />
                    ) : (
                      <span className="text-base font-extrabold text-slate-900">
                        {invoice.businessName.slice(0, 2).toUpperCase()}
                      </span>
                    )}
                  </div>

                  <h1 className="text-[17px] font-bold leading-5 text-slate-900">
                    {invoice.businessName}
                  </h1>

                  <div className="mt-1 space-y-0.5 text-[8.5px] font-medium leading-3 text-slate-500">
                    <div>
                      {[
                        invoice.addressHouseNumber,
                        invoice.addressStreet,
                        invoice.addressCity,
                        invoice.addressDistrict,
                      ]
                        .filter(Boolean)
                        .join(", ")}
                    </div>

                    <div>
                      {[
                        invoice.addressState,
                        invoice.addressCountry,
                        invoice.addressPincode,
                      ]
                        .filter(Boolean)
                        .join(", ")}
                    </div>

                    <div className="flex flex-wrap gap-x-4 gap-y-0.5">
                      {invoice.phone && (
                        <span>
                          Phone: {invoice.phoneCountryCode} {invoice.phone}
                        </span>
                      )}

                      {invoice.email && (
                        <span>
                          Email: {invoice.email}
                        </span>
                      )}
                    </div>

                    {(invoice.website || invoice.gst) && (
                      <div className="flex flex-wrap gap-x-4 gap-y-0.5">
                        {invoice.website && (
                          <span>Website: {invoice.website}</span>
                        )}

                        {invoice.gst && (
                          <span>GSTIN: {invoice.gst}</span>
                        )}
                      </div>
                    )}
                  </div>
                </div>

                {/* INVOICE TITLE */}
                <div className="w-[175px] shrink-0 pt-3 text-right">
                  <h2
                    className="
                      font-serif
                      text-[27px]
                      font-normal
                      leading-8
                      text-slate-900
                    "
                  >
                    INVOICE
                  </h2>
                </div>
              </div>

              {/* ======================================================== */}
              {/* BILL TO / INVOICE DETAILS                                  */}
              {/* ======================================================== */}

              <div
                className="
                  mt-3
                  grid
                  grid-cols-2
                  overflow-hidden
                  rounded
                  border
                  border-slate-300
                "
              >
                {/* BILL TO */}
                <div className="min-w-0 border-r border-slate-300 p-2.5">
                  <h3
                    className="
                      mb-1.5
                      text-[8px]
                      font-extrabold
                      tracking-wider
                      text-emerald-700
                    "
                  >
                    BILL TO
                  </h3>

                  <strong className="block text-[9px] leading-3.5 text-slate-900">
                    {invoice.customerName || "Customer name"}
                  </strong>

                  {invoice.customerCompany && (
                    <span className="block text-[8px] font-medium leading-3 text-slate-500">
                      {invoice.customerCompany}
                    </span>
                  )}

                  <span className="mt-0.5 block text-[8px] font-medium leading-3 text-slate-500">
                    {[
                      invoice.customerHouseNumber,
                      invoice.customerStreet,
                      invoice.customerCity,
                      invoice.customerDistrict,
                    ]
                      .filter(Boolean)
                      .join(", ")}
                  </span>

                  <span className="block text-[8px] font-medium leading-3 text-slate-500">
                    {[
                      invoice.customerState,
                      invoice.customerCountry,
                      invoice.customerPincode,
                    ]
                      .filter(Boolean)
                      .join(", ")}
                  </span>

                  {invoice.customerPhone && (
                    <span className="block text-[8px] font-medium leading-3 text-slate-500">
                      Phone: {invoice.customerPhoneCountryCode} {invoice.customerPhone}
                    </span>
                  )}

                  {invoice.customerEmail && (
                    <span className="block text-[8px] font-medium leading-3 text-slate-500">
                      Email: {invoice.customerEmail}
                    </span>
                  )}

                  {invoice.customerGst && (
                    <span className="block text-[8px] font-medium leading-3 text-slate-500">
                      GSTIN: {invoice.customerGst}
                    </span>
                  )}
                </div>

                {/* INVOICE DETAILS */}
                <div className="min-w-0 p-2.5">
                  <h3
                    className="
                      mb-1.5
                      text-[8px]
                      font-extrabold
                      tracking-wider
                      text-slate-900
                    "
                  >
                    INVOICE DETAILS
                  </h3>

                  <div className="grid grid-cols-[72px_1fr] gap-y-1 text-[8px] leading-3 text-slate-500">
                    <span>Date</span>
                    <strong className="text-slate-900">
                      : {invoice.invoiceDate || "-"}
                    </strong>

                    <span>Due Date</span>
                    <strong className="text-slate-900">
                      : {invoice.dueDate || "-"}
                    </strong>

                    <span>Terms</span>
                    <strong className="text-slate-900">
                      : {invoice.paymentTerms || "-"}
                    </strong>

                    <span>Invoice #</span>
                    <strong className="text-slate-900">
                      : {invoice.invoiceNumber || "-"}
                    </strong>

                    <span>Ship To</span>
                    <strong className="text-slate-900">
                      : {invoice.shippingSameAsBilling
                        ? invoice.customerName || "-"
                        : invoice.customerName || "-"}
                    </strong>
                  </div>

                  <div className="mt-1.5 text-[7.5px] font-medium leading-3 text-slate-500">
                    {invoice.shippingSameAsBilling ? (
                      <>
                        <div>
                          {[
                            invoice.customerHouseNumber,
                            invoice.customerStreet,
                            invoice.customerCity,
                          ]
                            .filter(Boolean)
                            .join(", ")}
                        </div>
                        <div>
                          {[
                            invoice.customerState,
                            invoice.customerCountry,
                            invoice.customerPincode,
                          ]
                            .filter(Boolean)
                            .join(", ")}
                        </div>
                      </>
                    ) : (
                      <>
                        <div>
                          {[
                            invoice.shippingHouseNumber,
                            invoice.shippingStreet,
                            invoice.shippingCity,
                          ]
                            .filter(Boolean)
                            .join(", ")}
                        </div>
                        <div>
                          {[
                            invoice.shippingState,
                            invoice.shippingCountry,
                            invoice.shippingPincode,
                          ]
                            .filter(Boolean)
                            .join(", ")}
                        </div>
                      </>
                    )}
                  </div>
                </div>
              </div>

              {/* ======================================================== */}
              {/* ITEMS TABLE                                               */}
              {/* ======================================================== */}

              <table
                className="
                  mt-3
                  w-full
                  table-fixed
                  border-collapse
                  text-[8px]
                "
              >
                <thead>
                  <tr className="bg-slate-900 text-white font-medium">
                    <th
                      className="
                        w-[33%]
                        px-1.5
                        py-1.5
                        text-left
                        font-bold
                      "
                    >
                      ITEM
                    </th>

                    <th
                      className="
                        w-[8%]
                        px-1
                        py-1.5
                        font-bold
                      "
                    >
                      QTY
                    </th>

                    <th
                      className="
                        w-[13%]
                        px-1
                        py-1.5
                        font-bold
                      "
                    >
                      UNIT PRICE
                    </th>

                    <th
                      className="
                        w-[8%]
                        px-1
                        py-1.5
                        font-bold
                      "
                    >
                      DISC.
                    </th>

                    <th
                      className="
                        w-[8%]
                        px-1
                        py-1.5
                        font-bold
                      "
                    >
                      TAX
                    </th>

                    <th
                      className="
                        w-[13%]
                        px-1
                        py-1.5
                        font-bold
                      "
                    >
                      TAX AMT
                    </th>

                    <th
                      className="
                        w-[17%]
                        px-1
                        py-1.5
                        font-bold
                      "
                    >
                      LINE TOTAL
                    </th>
                  </tr>
                </thead>

                <tbody>
                  {calculations.calculatedItems.map(
                    (item) => (
                      <tr
                        key={item.id}
                        className="
                          border-b
                          border-slate-200
                          align-top
                        "
                      >
                        <td
                          className="
                            px-1.5
                            py-1.5
                            text-left
                          "
                        >
                          <strong
                            className="
                              block
                              text-[9px]
                            "
                          >
                            {item.name ||
                              "Item / service"}
                          </strong>

                          <small
                            className="
                              block
                              text-[7.5px]
                              leading-2.5
                              text-slate-500 font-medium
                            "
                          >
                            SKU: {item.sku || "-"}
                          </small>

                          <small
                            className="
                              block
                              text-[7.5px]
                              leading-2.5
                              text-slate-500 font-medium
                            "
                          >
                            {item.description}
                          </small>
                        </td>

                        <td
                          className="
                            px-1
                            py-1.5
                            text-center
                          "
                        >
                          <span className="whitespace-nowrap">
                            {item.quantity} {item.unit}
                          </span>
                        </td>

                        <td
                          className="
                            px-1
                            py-1.5
                            text-center
                          "
                        >
                          {displayCurrency(item.unitPrice)}
                        </td>

                        <td
                          className="
                            px-1
                            py-1.5
                            text-center
                          "
                        >
                          {item.discount}%
                        </td>

                        <td
                          className="
                            px-1
                            py-1.5
                            text-center
                          "
                        >
                          {item.tax}%
                        </td>

                        <td
                          className="
                            px-1
                            py-1.5
                            text-center
                          "
                        >
                          {displayCurrency(item.taxAmount)}
                        </td>

                        <td
                          className="
                            px-1
                            py-1.5
                            text-center
                            font-bold
                          "
                        >
                          {displayCurrency(item.lineTotal)}
                        </td>
                      </tr>
                    ),
                  )}
                </tbody>
              </table>

              {/* ======================================================== */}
              {/* TOTALS                                                    */}
              {/* ======================================================== */}

              <div className="mt-1.5 flex justify-end">
                <div
                  className="
                    w-[245px]
                    space-y-0.5
                    text-[9px]
                    text-slate-500 font-medium
                  "
                >
                  <SummaryRow
                    label="Subtotal"
                    value={displayCurrency(calculations.subtotal)}
                  />

                  <SummaryRow
                    label="Total discount"
                    value={`-${displayCurrency(calculations.totalDiscount)}`}
                  />

                  <SummaryRow
                    label="Taxable amount"
                    value={displayCurrency(calculations.taxableAmount)}
                  />

                  {!invoice.interState ? (
                    <>
                      <SummaryRow
                        label="CGST"
                        value={displayCurrency(calculations.cgst)}
                      />

                      <SummaryRow
                        label="SGST"
                        value={displayCurrency(calculations.sgst)}
                      />
                    </>
                  ) : (
                    <SummaryRow
                      label="IGST"
                      value={displayCurrency(calculations.igst)}
                    />
                  )}

                  <SummaryRow
                    label="Other charges"
                    value={displayCurrency(invoice.otherCharges)}
                  />



                  {/* GRAND TOTAL */}

                  <div
                    className="
                      my-0.5
                      flex
                      items-center
                      justify-between
                      border-y
                      border-slate-900
                      py-1.5
                      text-[9px]
                      font-extrabold
                      text-slate-900
                    "
                  >
                    <span>GRAND TOTAL</span>

                    <strong>
                      {displayCurrency(calculations.roundedTotal)}
                    </strong>
                  </div>

                </div>
              </div>

              {/* ======================================================== */}
              {/* AMOUNT IN WORDS                                          */}
              {/* ======================================================== */}

              <div
                className="
                  mt-1.5
                  rounded
                  border
                  border-slate-300
                  px-2
                  py-1.5
                  text-[8px]
                  italic
                  text-slate-500 font-medium
                "
              >
                Amount in words:{" "}
                {numberToWords(
                  Math.round(
                    calculations.roundedTotal,
                  ),
                )}{" "}
                {selectedCurrency === "INR"
                  ? "Rupees Only"
                  : selectedCurrency === "USD"
                    ? "Dollars Only"
                    : selectedCurrency === "EUR"
                      ? "Euros Only"
                      : selectedCurrency === "GBP"
                        ? "Pounds Only"
                        : selectedCurrency === "JPY"
                          ? "Yen Only"
                          : `${selectedCurrency} Only`}
              </div>

              {/* ======================================================== */}
              {/* FOOTER                                                   */}
              {/* ======================================================== */}

              <div
                className="
                  mt-2.5
                  grid
                  grid-cols-3
                  gap-6
                "
              >
                <FooterBlock
                  title="NOTES"
                  text={invoice.notes}
                />

                <FooterBlock
                  title="TERMS & CONDITIONS"
                  text={invoice.terms}
                />

                <FooterBlock
                  title="PAYMENT INSTRUCTIONS"
                  text={
                    invoice.paymentInstructions
                  }
                />
              </div>

              {/* ======================================================== */}
              {/* SIGNATURE                                                 */}
              {/* ======================================================== */}

              {invoice.requireSignature && (
                <div
                  className="
                    mt-4
                    flex
                    w-40
                    flex-col
                    items-center
                    text-[8px]
                    text-slate-500 font-medium
                  "
                >
                  {invoice.signature ? (
                    <img
                      src={invoice.signature}
                      alt="Authorized signature"
                      className="
                        mb-1
                        h-10
                        w-36
                        object-contain
                      "
                    />
                  ) : (
                    <div
                      className="
                        mb-1
                        h-10
                        w-36
                        border-b
                        border-slate-900
                      "
                    />
                  )}

                  <span>
                    Authorized Signature
                  </span>
                </div>
              )}
            </article>
          </div>
        </div>
      </div>
    </section>
  );
}

/* -------------------------------------------------------------------------- */
/* Summary Row                                                                */
/* -------------------------------------------------------------------------- */

function SummaryRow({
  label,
  value,
}: {
  label: string;
  value: string;
}) {
  return (
    <div
      className="
        flex
        min-h-4
        items-center
        justify-between
        gap-3
      "
    >
      <span>{label}</span>

      <strong className="text-slate-900">
        {value}
      </strong>
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/* Footer Block                                                               */
/* -------------------------------------------------------------------------- */

function FooterBlock({
  title,
  text,
}: {
  title: string;
  text: string;
}) {
  return (
    <div>
      <h4
        className="
          mb-1
          text-[8px]
          font-extrabold
          tracking-wide
          text-emerald-700
        "
      >
        {title}
      </h4>

      <p
        className="
          m-0
          text-[8px]
          leading-2.5
          text-slate-500 font-medium
        "
      >
        {text}
      </p>
    </div>
  );
}