# Live Invoice Designer

A client-side live invoice designer built with:

- Next.js 16 App Router
- TypeScript
- Tailwind CSS v4
- Local shadcn/ui-style components under `components/ui`
- Geist font via `next/font/google`

The current version is intentionally frontend-only. Invoice data is held in React state so the form and A4 invoice preview update immediately without an API.

## Project structure

```text
app/
  globals.css
  layout.tsx
  page.tsx
components/
  invoice/
    invoice-designer.tsx
    invoice-form.tsx
    invoice-preview.tsx
  ui/
    button.tsx
    checkbox.tsx
    input.tsx
    label.tsx
    select.tsx
    textarea.tsx
lib/
  invoice-utils.ts
  utils.ts
types/
  invoice.ts
public/
components.json
```

## Run

```bash
npm install
npm run dev
```

Open `http://localhost:3000`.

## Production

```bash
npm run build
npm start
```

## Notes

- The right-hand invoice is a live preview and does not have its own scrollbar.
- The print action uses the browser print dialog and prints the invoice as A4.
- Logo and signature uploads are kept in browser memory as data URLs for the current session.
- No Node.js/.NET API is connected yet; that can be added later without changing the invoice calculation or preview structure.
