import axios, {
  AxiosError,
  InternalAxiosRequestConfig,
} from "axios";

/* ============================================================
   AKRA COMMON API
   ============================================================ */

const BASE_URL =
  process.env.AKRA_API_BASE_URL ||
  "https://akra-common-api.onrender.com";

/* ============================================================
   TOKEN TYPES
   ============================================================ */

type TokenResponse = {
  success?: boolean;
  message?: string;
  data?: {
    accessToken?: string;
    refreshToken?: string;
  };
  accessToken?: string;
  refreshToken?: string;
};

/* ============================================================
   AXIOS INSTANCE
   ============================================================ */

export const api = axios.create({
  baseURL: BASE_URL,
  headers: {
    "Content-Type": "application/json",
  },
  timeout: 30000,
});

/* ============================================================
   REFRESH TOKEN CLIENT
   ============================================================ */

const refreshClient = axios.create({
  baseURL: BASE_URL,
  headers: {
    "Content-Type": "application/json",
  },
  timeout: 30000,
});

/* ============================================================
   TOKEN STORAGE
   ============================================================ */

/*
  For now, the refresh token comes from .env.local.

  We keep the current access token only in memory.
  It is NOT placed in NEXT_PUBLIC_* variables.
*/

let accessToken: string | null = null;

let refreshToken: string | null =
  process.env.AKRA_REFRESH_TOKEN || null;

/* ============================================================
   REFRESH STATE
   ============================================================ */

let isRefreshing = false;

let refreshPromise: Promise<string> | null = null;

/* ============================================================
   GET NEW ACCESS TOKEN
   ============================================================ */

async function refreshAccessToken(): Promise<string> {
  if (refreshPromise) {
    return refreshPromise;
  }

  if (!refreshToken) {
    throw new Error(
      "AKRA_REFRESH_TOKEN is not configured",
    );
  }

  refreshPromise = (async () => {
    try {
      console.log(
        "Refreshing AKRA access token...",
      );

      const response =
        await refreshClient.post<TokenResponse>(
          "/auth/refresh-token",
          {
            refreshToken,
          },
        );

      const responseData = response.data;

      const newAccessToken =
        responseData.data?.accessToken ??
        responseData.accessToken;

      const newRefreshToken =
        responseData.data?.refreshToken ??
        responseData.refreshToken;

      if (!newAccessToken) {
        throw new Error(
          "Refresh API did not return an access token",
        );
      }

      accessToken = newAccessToken;

      if (newRefreshToken) {
        refreshToken = newRefreshToken;
      }

      console.log(
        "AKRA access token refreshed successfully",
      );

      return newAccessToken;
    } finally {
      refreshPromise = null;
    }
  })();

  return refreshPromise;
}

/* ============================================================
   REQUEST INTERCEPTOR
   ============================================================ */

api.interceptors.request.use(
  async (
    config: InternalAxiosRequestConfig,
  ) => {
    /*
      If we don't have an access token yet,
      obtain one using the refresh token.
    */

    if (!accessToken) {
      accessToken =
        await refreshAccessToken();
    }

    if (accessToken && config.headers) {
      config.headers.Authorization =
        `Bearer ${accessToken}`;
    }

    return config;
  },
  (error: AxiosError) =>
    Promise.reject(error),
);

/* ============================================================
   RESPONSE INTERCEPTOR
   ============================================================ */

api.interceptors.response.use(
  (response) => response,

  async (error: AxiosError) => {
    const originalRequest =
      error.config as
        | (InternalAxiosRequestConfig & {
            _retry?: boolean;
          })
        | undefined;

    /*
      Only handle 401 responses once.
    */

    if (
      error.response?.status !== 401 ||
      !originalRequest ||
      originalRequest._retry
    ) {
      return Promise.reject(error);
    }

    originalRequest._retry = true;

    try {
      /*
        Get a fresh access token.
      */

      const newAccessToken =
        await refreshAccessToken();

      /*
        Put the new token on the
        original request.
      */

      if (originalRequest.headers) {
        originalRequest.headers.Authorization =
          `Bearer ${newAccessToken}`;
      }

      /*
        Retry the original API request.
      */

      return api(originalRequest);
    } catch (refreshError) {
      console.error(
        "AKRA token refresh failed:",
        refreshError,
      );

      accessToken = null;

      return Promise.reject(
        refreshError,
      );
    }
  },
);

/* ============================================================
   GENERIC GET
   ============================================================ */

export async function getData<T>(
  endpoint: string,
  params?: Record<string, unknown>,
): Promise<T> {
  try {
    const response =
      await api.get<T>(
        endpoint,
        {
          params,
        },
      );

    return response.data;
  } catch (error) {
    console.error(
      `API GET Error [${endpoint}]:`,
      error,
    );

    throw error;
  }
}

/* ============================================================
   GENERIC POST
   ============================================================ */

export async function postData<T>(
  endpoint: string,
  payload: unknown = {},
): Promise<T> {
  try {
    const response =
      await api.post(endpoint, payload);

    const data =
      response.data as {
        data?: T;
      } & T;

    return (
      data?.data ??
      data
    ) as T;
  } catch (error) {
    console.error(
      `API POST Error [${endpoint}]:`,
      error,
    );

    throw error;
  }
}

/* ============================================================
   GENERIC PUT
   ============================================================ */

export async function putData<T>(
  endpoint: string,
  payload: unknown = {},
): Promise<T> {
  try {
    const response =
      await api.put(endpoint, payload);

    const data =
      response.data as {
        data?: T;
      } & T;

    return (
      data?.data ??
      data
    ) as T;
  } catch (error) {
    console.error(
      `API PUT Error [${endpoint}]:`,
      error,
    );

    throw error;
  }
}

/* ============================================================
   GENERIC DELETE
   ============================================================ */

export async function deleteData<T>(
  endpoint: string,
  payload: unknown = {},
): Promise<T> {
  try {
    const response =
      await api.delete(endpoint, {
        data: payload,
      });

    const data =
      response.data as {
        data?: T;
      } & T;

    return (
      data?.data ??
      data
    ) as T;
  } catch (error) {
    console.error(
      `API DELETE Error [${endpoint}]:`,
      error,
    );

    throw error;
  }
}