import { postData } from "@/services/api";

import type {
  GetCompanyListResponse,
  GetInvoiceBankDetailsResponse,
  GetCustomerDetailsResponse,
  GetInvoicesResponse,
} from "@/types/invoice-api";

/* ============================================================
   GET COMPANY LIST
   ============================================================ */

export const GetCompanyList =
  async (): Promise<GetCompanyListResponse> => {
    try {
      const response = await fetch(
        "/api/company",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            RequestParamType: "GetCompanyList",
          }),
          cache: "no-store",
        },
      );

      if (!response.ok) {
        const errorData =
          await response.json().catch(() => null);

        throw new Error(
          errorData?.message ||
            "Failed to fetch companies",
        );
      }

      const responseData =
        await response.json();

      return (
        responseData?.data ??
        responseData
      ) as GetCompanyListResponse;
    } catch (error) {
      console.error(
        "GetCompanyList API Error:",
        error,
      );

      throw error;
    }
  };

/* ============================================================
   GET INVOICE BANK DETAILS
   ============================================================ */

export const GetInvoiceBankDetails =
  async (
    companyId: number,
  ): Promise<GetInvoiceBankDetailsResponse> => {
    try {
      const response = await fetch(
        "/api/company",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            RequestParamType:
              "GetInvoiceBankDetails",
            json: JSON.stringify({
              CompanyID: companyId,
            }),
          }),
          cache: "no-store",
        },
      );

      if (!response.ok) {
        const errorData =
          await response.json().catch(() => null);

        throw new Error(
          errorData?.message ||
            "Failed to fetch bank details",
        );
      }

      const responseData =
        await response.json();

      return (
        responseData?.data ??
        responseData
      ) as GetInvoiceBankDetailsResponse;
    } catch (error) {
      console.error(
        "GetInvoiceBankDetails API Error:",
        error,
      );

      throw error;
    }
  };
 /* ============================================================
   GET CUSTOMER DETAILS
   ============================================================ */

export const GetCustomerDetails =
  async (
    companyId: string,
  ): Promise<GetCustomerDetailsResponse> => {
    try {
      const response = await fetch(
        "/api/company",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            RequestParamType:
              "GetCustomerDetails",

            json: {
              CompanyID: companyId,
            },
          }),
          cache: "no-store",
        },
      );

      if (!response.ok) {
        const errorData =
          await response.json().catch(() => null);

        throw new Error(
          errorData?.message ||
            "Failed to fetch customers",
        );
      }

      const responseData =
        await response.json();

      return (
        responseData?.data ??
        responseData
      ) as GetCustomerDetailsResponse;
    } catch (error) {
      console.error(
        "GetCustomerDetails API Error:",
        error,
      );

      throw error;
    }
  };
/* ============================================================
   GET CUSTOMER DETAILS
   ============================================================ */
  export const GetInvoices = async (
  invoiceId: string,
): Promise<GetInvoicesResponse> => {
  try {
    const response = await fetch("/api/company", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        RequestParamType: "GetInvoices",
        json: JSON.stringify({
          InvoiceID: invoiceId,
        }),
      }),
      cache: "no-store",
    });

    if (!response.ok) {
      throw new Error(`Failed to fetch invoice: ${response.status}`);
    }

    const responseData = await response.json();

    if (!responseData?.success) {
      throw new Error(
        responseData?.message || "Failed to fetch invoice",
      );
    }

    return responseData.data as GetInvoicesResponse;
  } catch (error) {
    console.error("GetInvoices error:", error);
    throw error;
  }
};