"use client";

import { useEffect, useMemo, useState } from "react";
import InvoiceDesigner from "@/components/invoice/invoice-designer";

type InvoiceStatus =
  | "Paid"
  | "Pending"
  | "Overdue";

type Invoice = {
  id: number;
  invoiceNumber: string;
  format: "US Invoice" | "Indian Invoice";
  businessName: string;
  customer: string;
  date: string;
  dueDate: string;
  paymentTerms: string;
  currency: string;
  amount: number;
  status: InvoiceStatus;
};

/* ============================================================
   HARD-CODED INVOICES
   ============================================================ */

const defaultInvoices: Invoice[] = [
  {
    id: 1,
    invoiceNumber: "INV-2026-001",
    format: "Indian Invoice",
    businessName: "AKRA Solutions Pvt. Ltd.",
    customer: "ScholarIT",
    date: "03/09/2026",
    dueDate: "18/09/2026",
    paymentTerms: "15 days",
    currency: "₹ INR",
    amount: 25000,
    status: "Paid",
  },

  {
    id: 2,
    invoiceNumber: "INV-2026-002",
    format: "US Invoice",
    businessName: "AKRA Solutions LLC",
    customer: "HCL Tech",
    date: "02/09/2026",
    dueDate: "17/09/2026",
    paymentTerms: "15 days",
    currency: "$ USD",
    amount: 48500,
    status: "Pending",
  },

  {
    id: 3,
    invoiceNumber: "INV-2026-003",
    format: "Indian Invoice",
    businessName: "AKRA Solutions Pvt. Ltd.",
    customer: "AKRA TREALX",
    date: "01/09/2026",
    dueDate: "15/09/2026",
    paymentTerms: "14 days",
    currency: "₹ INR",
    amount: 32750,
    status: "Overdue",
  },
];

/* ============================================================
   SEARCH
   Searches every property of every invoice.
   ============================================================ */

function invoiceMatchesSearch(
  invoice: Invoice,
  searchText: string,
): boolean {
  const value = searchText
    .trim()
    .toLowerCase();

  if (!value) {
    return true;
  }

  return Object.values(invoice).some(
    (field) =>
      String(field)
        .toLowerCase()
        .includes(value),
  );
}

/* ============================================================
   CURRENCY FORMATTERS
   ============================================================ */

function formatCompactAmount(
  amount: number,
  symbol: string,
) {
  const absAmount = Math.abs(amount);

  if (absAmount < 1000) {
    return `${symbol}${amount.toLocaleString(
      symbol === "₹" ? "en-IN" : "en-US",
    )}`;
  }

  if (absAmount < 1_000_000) {
    const value = Math.round(amount / 1000);
    return `${symbol}${value}K`;
  }

  if (absAmount < 1_000_000_000) {
    const value = Math.round((amount / 1_000_000) * 10) / 10;
    return `${symbol}${value % 1 === 0 ? value.toFixed(0) : value}M`;
  }

  const value = Math.round((amount / 1_000_000_000) * 10) / 10;
  return `${symbol}${value % 1 === 0 ? value.toFixed(0) : value}B`;
}

function formatINR(amount: number) {
  return formatCompactAmount(amount, "₹");
}

function formatUSD(amount: number) {
  return formatCompactAmount(amount, "$");
}

/* ============================================================
   COMPONENT
   ============================================================ */

export default function InvoiceList() {
  const [showDesigner, setShowDesigner] =
    useState(false);

  const [invoiceRows, setInvoiceRows] =
    useState<Invoice[]>(defaultInvoices);

  const [search, setSearch] = useState("");

  /* ==========================================================
     LOAD SUBMITTED INVOICES
     ========================================================== */

  useEffect(() => {
    try {
      const stored = JSON.parse(
        localStorage.getItem("invoice-list-submitted") || "[]",
      );

      if (Array.isArray(stored) && stored.length > 0) {
        setInvoiceRows([
          ...defaultInvoices,
          ...stored,
        ]);
      }
    } catch {
      // Keep the three hard-coded invoices if storage is unavailable.
    }
  }, []);

  /* ==========================================================
     FILTERED INVOICES
     ========================================================== */

  const filteredInvoices = useMemo(() => {
    return invoiceRows.filter((invoice) =>
      invoiceMatchesSearch(
        invoice,
        search,
      ),
    );
  }, [invoiceRows, search]);

  /* ==========================================================
     TOTAL INVOICES STATUS BREAKDOWN
     (drives the footer strip on the "Total Invoices" card)
     ========================================================== */

  const totalPaidCount = invoiceRows.filter(
    (invoice) => invoice.status === "Paid",
  ).length;

  const totalPendingCount = invoiceRows.filter(
    (invoice) => invoice.status === "Pending",
  ).length;

  const totalOverdueCount = invoiceRows.filter(
    (invoice) => invoice.status === "Overdue",
  ).length;

  /* ==========================================================
     INDIAN INVOICE VALUES
     ========================================================== */

  const indianInvoices = invoiceRows.filter(
    (invoice) =>
      invoice.format === "Indian Invoice",
  );

  const indianPaidAmount =
    indianInvoices
      .filter(
        (invoice) =>
          invoice.status === "Paid",
      )
      .reduce(
        (total, invoice) =>
          total + invoice.amount,
        0,
      );

  const indianPendingAmount =
    indianInvoices
      .filter(
        (invoice) =>
          invoice.status === "Pending",
      )
      .reduce(
        (total, invoice) =>
          total + invoice.amount,
        0,
      );

  const indianOverdueAmount =
    indianInvoices
      .filter(
        (invoice) =>
          invoice.status === "Overdue",
      )
      .reduce(
        (total, invoice) =>
          total + invoice.amount,
        0,
      );

  const indianTotalAmount =
    indianInvoices.reduce(
      (total, invoice) =>
        total + invoice.amount,
      0,
    );

  /* ==========================================================
     US INVOICE VALUES
     ========================================================== */

  const usInvoices = invoiceRows.filter(
    (invoice) =>
      invoice.format === "US Invoice",
  );

  const usPaidAmount =
    usInvoices
      .filter(
        (invoice) =>
          invoice.status === "Paid",
      )
      .reduce(
        (total, invoice) =>
          total + invoice.amount,
        0,
      );

  const usPendingAmount =
    usInvoices
      .filter(
        (invoice) =>
          invoice.status === "Pending",
      )
      .reduce(
        (total, invoice) =>
          total + invoice.amount,
        0,
      );

  const usOverdueAmount =
    usInvoices
      .filter(
        (invoice) =>
          invoice.status === "Overdue",
      )
      .reduce(
        (total, invoice) =>
          total + invoice.amount,
        0,
      );

  const usTotalAmount =
    usInvoices.reduce(
      (total, invoice) =>
        total + invoice.amount,
      0,
    );

  /* ==========================================================
     DESIGNER VIEW
     ========================================================== */

  if (showDesigner) {
    return (
      <div className="h-dvh w-full overflow-hidden">
        <InvoiceDesigner
          onBack={() => setShowDesigner(false)}
        />
      </div>
    );
  }

  /* ==========================================================
     LIST PAGE
     ========================================================== */

  return (
    <main className="min-h-dvh w-full bg-[#F1F5F9] text-slate-900">
      {/* ======================================================
          PAGE HEADER + SUMMARY CARDS
          Title sits on the left; the three cards now sit in the
          space to the right, in the same compact row.
          ====================================================== */}

      <section
        className="border-b border-slate-200 bg-white px-8 py-3"
      >
        <div
          className="flex flex-col gap-2 xl:flex-row xl:items-center xl:justify-between"
        >
          <div>
            <h1
              className="text-[22px] font-bold leading-tight text-slate-900"
            >
              Invoices
            </h1>

            <p
              className="mt-1 text-[12px] text-slate-500"
            >
              Manage and track your invoices
            </p>
          </div>

          <div
            className="grid grid-cols-1 gap-2 sm:grid-cols-3 xl:grid-cols-[145px_220px_220px]"
          >
          {/* ==================================================
              TOTAL INVOICES
              ================================================== */}

          <div
            className="h-[66px] overflow-hidden rounded-lg border border-slate-200 bg-white shadow-sm transition-shadow duration-200 hover:shadow-md"
          >
            {/* CARD HEADER — same 41px header row as the other two cards,
                with the total count taking the badge's spot on the right */}

            <div
              className="flex h-[30px] items-center justify-between border-b border-slate-100 px-3"
            >
              <p
                className="text-[10px] font-semibold leading-none text-slate-900"
              >
                Total Invoices
              </p>

              <span
                className="text-[14px] font-bold leading-none text-slate-900"
              >
                {invoiceRows.length}
              </span>
            </div>

            {/* CARD VALUES — same 43px, 3-column body pattern as the
                Indian/US cards, so nothing wraps or gets clipped */}

            <div
              className="grid h-[36px] grid-cols-3"
            >
              {/* PAID */}

              <div
                className="flex flex-col items-center justify-center border-r border-slate-100"
              >
                <span
                  className="text-[7px] leading-none text-slate-400"
                >
                  Paid
                </span>

                <span
                  className="mt-0.5 text-[12px] font-semibold leading-none text-emerald-600"
                >
                  {totalPaidCount}
                </span>
              </div>

              {/* PENDING */}

              <div
                className="flex flex-col items-center justify-center border-r border-slate-100"
              >
                <span
                  className="text-[7px] leading-none text-slate-400"
                >
                  Pending
                </span>

                <span
                  className="mt-0.5 text-[12px] font-semibold leading-none text-orange-600"
                >
                  {totalPendingCount}
                </span>
              </div>

              {/* OVERDUE */}

              <div
                className="flex flex-col items-center justify-center"
              >
                <span
                  className="text-[7px] leading-none text-slate-400"
                >
                  Overdue
                </span>

                <span
                  className="mt-0.5 text-[12px] font-semibold leading-none text-red-600"
                >
                  {totalOverdueCount}
                </span>
              </div>
            </div>
          </div>

          {/* ==================================================
              INDIAN INVOICE
              ================================================== */}

          <div
            className="h-[66px] overflow-hidden rounded-lg border border-slate-200 bg-white shadow-sm transition-shadow duration-200 hover:shadow-md"
          >
            {/* CARD HEADER */}

            <div
              className="flex h-[30px] items-center justify-between border-b border-slate-100 px-3"
            >
              <p
                className="text-[10px] font-semibold leading-none text-slate-900"
              >
                Indian Invoice
              </p>

              <span
                className="rounded-full bg-emerald-50 px-2 py-0.5 text-[8px] font-semibold text-emerald-700"
              >
                ₹ INR
              </span>
            </div>

            {/* CARD VALUES */}

            <div
              className="grid h-[36px] grid-cols-4"
            >
              {/* COUNT */}

              <div
                className="flex flex-col items-center justify-center border-r border-slate-100"
              >
                <span
                  className="text-[7px] leading-none text-slate-400"
                >
                  Count
                </span>

                <span
                  className="mt-0.5 text-[14px] font-semibold text-slate-900"
                >
                  {indianInvoices.length}
                </span>
              </div>

              {/* AMOUNT */}

              <div
                className="flex flex-col items-center justify-center border-r border-slate-100"
              >
                <span
                  className="text-[7px] leading-none text-slate-400"
                >
                  Amount
                </span>

                <span
                  className="mt-0.5 text-[11px] font-semibold leading-none text-[#008A45] whitespace-nowrap"
                >
                  {formatINR(
                    indianTotalAmount,
                  )}
                </span>
              </div>

              {/* PENDING */}

              <div
                className="flex flex-col items-center justify-center border-r border-slate-100"
              >
                <span
                  className="text-[7px] leading-none text-slate-400"
                >
                  Pending
                </span>

                <span
                  className="mt-0.5 text-[11px] font-semibold leading-none text-orange-600 whitespace-nowrap"
                >
                  {formatINR(
                    indianPendingAmount,
                  )}
                </span>
              </div>

              {/* OVERDUE */}

              <div
                className="flex flex-col items-center justify-center"
              >
                <span
                  className="text-[7px] leading-none text-slate-400"
                >
                  Overdue
                </span>

                <span
                  className="mt-0.5 text-[11px] font-semibold leading-none text-red-600 whitespace-nowrap"
                >
                  {formatINR(
                    indianOverdueAmount,
                  )}
                </span>
              </div>
            </div>
          </div>

          {/* ==================================================
              US INVOICE
              ================================================== */}

          <div
            className="h-[66px] overflow-hidden rounded-lg border border-slate-200 bg-white shadow-sm transition-shadow duration-200 hover:shadow-md"
          >
            {/* CARD HEADER */}

            <div
              className="flex h-[30px] items-center justify-between border-b border-slate-100 px-3"
            >
              <p
                className="text-[10px] font-semibold leading-none text-slate-900"
              >
                US Invoice
              </p>

              <span
                className="rounded-full bg-blue-50 px-2 py-0.5 text-[8px] font-semibold text-blue-700"
              >
                $ USD
              </span>
            </div>

            {/* CARD VALUES */}

            <div
              className="grid h-[36px] grid-cols-4"
            >
              {/* COUNT */}

              <div
                className="flex flex-col items-center justify-center border-r border-slate-100"
              >
                <span
                  className="text-[7px] leading-none text-slate-400"
                >
                  Count
                </span>

                <span
                  className="mt-0.5 text-[14px] font-semibold text-slate-900"
                >
                  {usInvoices.length}
                </span>
              </div>

              {/* AMOUNT */}

              <div
                className="flex flex-col items-center justify-center border-r border-slate-100"
              >
                <span
                  className="text-[7px] leading-none text-slate-400"
                >
                  Amount
                </span>

                <span
                  className="mt-0.5 text-[11px] font-semibold leading-none text-[#008A45] whitespace-nowrap"
                >
                  {formatUSD(usTotalAmount)}
                </span>
              </div>

              {/* PENDING */}

              <div
                className="flex flex-col items-center justify-center border-r border-slate-100"
              >
                <span
                  className="text-[7px] leading-none text-slate-400"
                >
                  Pending
                </span>

                <span
                  className="mt-0.5 text-[11px] font-semibold leading-none text-orange-600 whitespace-nowrap"
                >
                  {formatUSD(
                    usPendingAmount,
                  )}
                </span>
              </div>

              {/* OVERDUE */}

              <div
                className="flex flex-col items-center justify-center"
              >
                <span
                  className="text-[7px] leading-none text-slate-400"
                >
                  Overdue
                </span>

                <span
                  className="mt-0.5 text-[11px] font-semibold leading-none text-red-600 whitespace-nowrap"
                >
                  {formatUSD(
                    usOverdueAmount,
                  )}
                </span>
              </div>
            </div>
          </div>
          </div>
        </div>
      </section>

      {/* ======================================================
          INVOICE TABLE
          ====================================================== */}

      <div
        className="px-8 py-4"
      >
        <section
          className="overflow-hidden rounded-lg border border-slate-200 bg-white shadow-sm"
        >
          {/* ==================================================
              TOOLBAR
              ONLY SEARCH + ADD INVOICE
              ================================================== */}

          <div
            className="flex min-h-[67px] items-center justify-between gap-3 border-b border-slate-200 px-5 py-3"
          >
            {/* TITLE */}

            <div>
              <h2
                className="text-[16px] font-semibold text-slate-900"
              >
                Invoice Entries
              </h2>

              <p
                className="mt-0.5 text-[10px] text-slate-400"
              >
                All invoice records
              </p>
            </div>

            {/* SEARCH + ADD */}

            <div
              className="flex items-center gap-2"
            >
              {/* SEARCH */}

              <div
                className="relative"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="15"
                  height="15"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
                >
                  <circle
                    cx="11"
                    cy="11"
                    r="8"
                  />

                  <path d="m21 21-4.3-4.3" />
                </svg>

                <input
                  type="text"
                  value={search}
                  onChange={(event) =>
                    setSearch(
                      event.target.value,
                    )
                  }
                  placeholder="Search invoices..."
                  className="h-9 w-[280px] rounded-md border border-slate-200 bg-white pl-9 pr-3 text-[11px] text-slate-700 outline-none placeholder:text-slate-400 focus:border-[#2F4F3E] focus:ring-1 focus:ring-[#2F4F3E]/20"
                />
              </div>

              {/* ADD INVOICE */}

              <button
                type="button"
                onClick={() =>
                  setShowDesigner(true)
                }
                className="flex h-9 items-center gap-2 rounded-md bg-[#2F4F3E] px-4 text-[11px] font-semibold text-white shadow-sm transition hover:bg-[#243D30]"
              >
                <span
                  className="text-[17px] leading-none"
                >
                  +
                </span>

                Add Invoice
              </button>
            </div>
          </div>

          {/* ==================================================
              TABLE
              HORIZONTAL SCROLL
              ================================================== */}

          <div
            className="w-full overflow-x-auto"
          >
            <table
              className="min-w-[1500px] w-full border-collapse"
            >
              {/* =================================================
                  TABLE HEADER
                  ================================================= */}

              <thead>
                <tr
                  className="border-b border-slate-200 bg-slate-50"
                >
                  <th className="table-header">
                    Invoice #
                  </th>

                  <th className="table-header">
                    Format
                  </th>

                  <th className="table-header">
                    Business / Company
                  </th>

                  <th className="table-header">
                    Customer
                  </th>

                  <th className="table-header">
                    Invoice Date
                  </th>

                  <th className="table-header">
                    Due Date
                  </th>

                  <th className="table-header">
                    Payment Terms
                  </th>

                  <th className="table-header">
                    Currency
                  </th>

                  <th
                    className="whitespace-nowrap px-4 py-2.5 text-right text-[10px] font-semibold uppercase tracking-wide text-slate-600"
                  >
                    Amount
                  </th>

                  <th
                    className="whitespace-nowrap px-4 py-2.5 text-center text-[10px] font-semibold uppercase tracking-wide text-slate-600"
                  >
                    Status
                  </th>

                  <th
                    className="whitespace-nowrap px-5 py-2.5 text-center text-[10px] font-semibold uppercase tracking-wide text-slate-600"
                  >
                    Action
                  </th>
                </tr>
              </thead>

              {/* =================================================
                  TABLE BODY
                  ================================================= */}

              <tbody>
                {filteredInvoices.map(
                  (invoice) => (
                    <tr
                      key={invoice.id}
                      className="border-b border-slate-100 transition hover:bg-slate-50"
                    >
                      {/* INVOICE NUMBER */}

                      <td
                        className="whitespace-nowrap px-5 py-2.5 text-[11px] font-semibold text-[#2F4F3E]"
                      >
                        {invoice.invoiceNumber}
                      </td>

                      {/* FORMAT */}

                      <td
                        className="whitespace-nowrap px-4 py-2.5 text-[11px] text-slate-600"
                      >
                        {invoice.format}
                      </td>

                      {/* BUSINESS */}

                      <td
                        className="whitespace-nowrap px-4 py-2.5 text-[11px] text-slate-700"
                      >
                        {invoice.businessName}
                      </td>

                      {/* CUSTOMER */}

                      <td
                        className="whitespace-nowrap px-4 py-2.5 text-[11px] font-medium text-slate-700"
                      >
                        {invoice.customer}
                      </td>

                      {/* INVOICE DATE */}

                      <td
                        className="whitespace-nowrap px-4 py-2.5 text-[11px] text-slate-500"
                      >
                        {invoice.date}
                      </td>

                      {/* DUE DATE */}

                      <td
                        className="whitespace-nowrap px-4 py-2.5 text-[11px] text-slate-500"
                      >
                        {invoice.dueDate}
                      </td>

                      {/* PAYMENT TERMS */}

                      <td
                        className="whitespace-nowrap px-4 py-2.5 text-[11px] text-slate-500"
                      >
                        {invoice.paymentTerms}
                      </td>

                      {/* CURRENCY */}

                      <td
                        className="whitespace-nowrap px-4 py-2.5 text-[11px] text-slate-500"
                      >
                        {invoice.currency}
                      </td>

                      {/* AMOUNT */}

                      <td
                        className="whitespace-nowrap px-4 py-2.5 text-right text-[11px] font-semibold text-slate-800"
                      >
                        {invoice.currency.startsWith(
                          "$",
                        )
                          ? formatUSD(
                              invoice.amount,
                            )
                          : formatINR(
                              invoice.amount,
                            )}
                      </td>

                      {/* STATUS */}

                      <td
                        className="whitespace-nowrap px-4 py-2.5 text-center"
                      >
                        <span
                          className={`
                            inline-flex
                            min-w-[62px]
                            items-center
                            justify-center
                            rounded-full
                            px-2.5
                            py-1
                            text-[9px]
                            font-semibold
                            ${
                              invoice.status ===
                              "Paid"
                                ? "bg-emerald-100 text-emerald-700"
                                : invoice.status ===
                                    "Pending"
                                  ? "bg-orange-100 text-orange-700"
                                  : "bg-red-100 text-red-700"
                            }
                          `}
                        >
                          {invoice.status}
                        </span>
                      </td>

                      {/* =================================================
                          ACTIONS
                          EYE + EDIT
                          SAME ROW HEIGHT
                          ================================================= */}

                      <td
                        className="whitespace-nowrap px-5 py-2.5 text-center"
                      >
                        <div
                          className="flex items-center justify-center gap-1.5"
                        >
                          {/* VIEW */}

                          <button
                            type="button"
                            title="View Invoice"
                            aria-label={`View ${invoice.invoiceNumber}`}
                            onClick={() =>
                              setShowDesigner(
                                true,
                              )
                            }
                            className="inline-flex h-7 w-7 items-center justify-center rounded-md border border-slate-200 bg-white text-slate-500 transition hover:border-[#2F4F3E] hover:bg-[#2F4F3E]/5 hover:text-[#2F4F3E]"
                          >
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="14"
                              height="14"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="currentColor"
                              strokeWidth="2"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                            >
                              <path
                                d="M2.062 12.348 a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1 -19.876 0"
                              />

                              <circle
                                cx="12"
                                cy="12"
                                r="3"
                              />
                            </svg>
                          </button>

                          {/* EDIT */}

                          <button
                            type="button"
                            title="Edit Invoice"
                            aria-label={`Edit ${invoice.invoiceNumber}`}
                            onClick={() =>
                              setShowDesigner(
                                true,
                              )
                            }
                            className="inline-flex h-7 w-7 items-center justify-center rounded-md border border-slate-200 bg-white text-slate-500 transition hover:border-[#2F4F3E] hover:bg-[#2F4F3E]/5 hover:text-[#2F4F3E]"
                          >
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="14"
                              height="14"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="currentColor"
                              strokeWidth="2"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                            >
                              <path d="M12 20h9" />

                              <path
                                d="M16.5 3.5 a2.121 2.121 0 0 1 3 3 L7 19 l-4 1 1-4 4 -4 Z"
                              />
                            </svg>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ),
                )}

                {/* NO RESULTS */}

                {filteredInvoices.length ===
                  0 && (
                    <tr>
                      <td
                        colSpan={11}
                        className="px-6 py-8 text-center text-[11px] text-slate-400"
                      >
                        No invoices found
                      </td>
                    </tr>
                  )}
              </tbody>
            </table>
          </div>

          {/* ==================================================
              FOOTER
              ================================================== */}

          <div
            className="flex min-h-[40px] items-center justify-between border-t border-slate-200 px-5 py-2"
          >
            {/* ROW COUNT */}

            <button
              type="button"
              className="flex h-7 items-center gap-2 rounded-md border border-slate-200 bg-white px-2.5 text-[10px] text-slate-600"
            >
              15

              <span className="text-[8px]">
                ⌄
              </span>
            </button>

            {/* RESULT COUNT */}

            <p
              className="text-[10px] text-slate-400"
            >
              Showing{" "}
              {filteredInvoices.length} of{" "}
              {invoiceRows.length} invoices
            </p>
          </div>
        </section>
      </div>

      {/* ======================================================
          SMALL TABLE HEADER UTILITY
          ====================================================== */}

      <style jsx>{`
        .table-header {
          white-space: nowrap;
          padding: 10px 16px;
          text-align: left;
          font-size: 10px;
          font-weight: 600;
          text-transform: uppercase;
          letter-spacing: 0.025em;
          color: #475569;
        }
      `}</style>
    </main>
  );
}
