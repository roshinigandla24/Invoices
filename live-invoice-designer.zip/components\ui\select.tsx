import * as React from "react";
import { cn } from "@/lib/utils";

export const Select = React.forwardRef<
  HTMLSelectElement,
  React.SelectHTMLAttributes<HTMLSelectElement>
>(({ className, children, ...props }, ref) => (
  <select
    ref={ref}
    className={cn(
      "w-full h-8",
      "rounded-md border border-slate-300",
      "bg-white",
      "px-2",
      "!text-[10px] !leading-4",
      "font-normal text-slate-900",
      "outline-none",
      "focus:border-blue-500",
      "focus:ring-2 focus:ring-blue-500/10",
      className,
    )}
    {...props}
  >
    {children}
  </select>
));

Select.displayName = "Select";