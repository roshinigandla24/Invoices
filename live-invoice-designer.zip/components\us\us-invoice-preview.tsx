"use client";

import {
  useCallback,
  useEffect,
  useRef,
  useState,
} from "react";

import type { USInvoiceData } from "@/types/us-invoice";

type USInvoicePreviewProps = {
  invoice: USInvoiceData;
  zoom?: number;
  onZoomOut?: () => void;
  onZoomIn?: () => void;
};

const A4_WIDTH = 794;
const A4_HEIGHT = 1123;

export function USInvoicePreview({
  invoice,
  zoom: externalZoom,
  onZoomOut: externalZoomOut,
  onZoomIn: externalZoomIn,
}: USInvoicePreviewProps) {
  const viewportRef = useRef<HTMLDivElement>(null);

  const [internalZoom, setInternalZoom] = useState(1);
  const zoom = externalZoom != null ? externalZoom / 100 : internalZoom;

  /* ================================================================
     TOTAL
     ================================================================ */

  const total = invoice.items.reduce(
    (sum, item) => {
      const quantity = Number(item.quantity || 0);
      const amount = Number(item.amount || 0);

      return sum + quantity * amount;
    },
    0,
  );

  /* ================================================================
     BUSINESS ADDRESS
     ================================================================ */

  const businessAddress2 = (
    invoice as USInvoiceData & {
      address2?: string;
    }
  ).address2 || "";

  const businessAddressLine1 = invoice.houseStreet || "";

  const businessAddressLine2 = businessAddress2;

  const businessAddressLine3 = [
    invoice.city,
    invoice.state,
    invoice.zipCode,
    invoice.country,
  ]
    .filter(Boolean)
    .join(" ");

  /* ================================================================
     CUSTOMER ADDRESS
     ================================================================ */

  const customerAddressLine1 = [
    invoice.customerStreet,
  ]
    .filter(Boolean)
    .join(", ");

  const customerAddressLine2 = [
    invoice.customerCity,
    invoice.customerState,
    invoice.customerZipCode,
  ]
    .filter(Boolean)
    .join(" ");

  /* ================================================================
     CUSTOMER PHONE
     ================================================================ */

  const customerPhone = [
    invoice.phoneCountryCode,
    invoice.customerPhone,
  ]
    .filter(Boolean)
    .join(" ");

  /* ================================================================
     FIT PAGE
     ================================================================ */

  const calculateFitZoom = useCallback(() => {
    const viewport = viewportRef.current;

    if (!viewport) {
      return 0.8;
    }

    const padding = 30;

    const availableWidth = Math.max(
      viewport.clientWidth - padding,
      200,
    );

    const availableHeight = Math.max(
      viewport.clientHeight - padding,
      200,
    );

    const widthScale =
      availableWidth / A4_WIDTH;

    const heightScale =
      availableHeight / A4_HEIGHT;

    const fitScale = Math.min(
      widthScale,
      heightScale,
    );

    return Math.min(
      Math.max(fitScale, 0.4),
      1,
    );
  }, []);

  /* ================================================================
     INITIAL FIT
     ================================================================ */

  useEffect(() => {
    const updateFit = () => {
      setInternalZoom(calculateFitZoom());
    };

    updateFit();

    window.addEventListener(
      "resize",
      updateFit,
    );

    return () => {
      window.removeEventListener(
        "resize",
        updateFit,
      );
    };
  }, [calculateFitZoom]);

  /* ================================================================
     ZOOM
     ================================================================ */

  const zoomIn = () => {
    if (externalZoomIn) {
      externalZoomIn();
      return;
    }

    setInternalZoom((current) =>
      Math.min(
        Number((current + 0.1).toFixed(2)),
        2,
      ),
    );
  };

  const zoomOut = () => {
    if (externalZoomOut) {
      externalZoomOut();
      return;
    }

    setInternalZoom((current) =>
      Math.max(
        Number((current - 0.1).toFixed(2)),
        0.4,
      ),
    );
  };

  const fitToPage = () => {
    setInternalZoom(calculateFitZoom());
  };

  /* ================================================================
     RENDER
     ================================================================ */

  return (
    <section className="flex h-full min-h-0 min-w-0 flex-col bg-slate-100 print:block print:h-[1123px] print:w-[794px] print:min-h-0 print:bg-white">
      {/* ============================================================
          PREVIEW HEADER
          ============================================================ */}

      <header className="flex h-[45px] shrink-0 items-center justify-between border-b border-slate-200 bg-slate-100 px-5 print:hidden">
        <div>
          <h2 className="text-base font-semibold text-slate-900">
            Live Invoice
          </h2>

          <p className="text-[11px] font-medium text-slate-500">
            Updates instantly while editing
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* ZOOM */}

          <div className="flex h-8 overflow-hidden rounded-md border border-slate-300 bg-white">
            <button
              type="button"
              onClick={zoomOut}
              className="flex h-full w-8 items-center justify-center text-sm text-slate-700 hover:bg-slate-100"
              aria-label="Zoom out"
            >
              −
            </button>

            <button
              type="button"
              onClick={fitToPage}
              className="min-w-[58px] border-x border-slate-200 px-2 text-[10px] font-medium text-slate-600 hover:bg-slate-50"
              title="Fit invoice to page"
            >
              {Math.round(zoom * 100)}%
            </button>

            <button
              type="button"
              onClick={zoomIn}
              className="flex h-full w-8 items-center justify-center text-sm text-slate-700 hover:bg-slate-100"
              aria-label="Zoom in"
            >
              +
            </button>
          </div>

          <span className="rounded-full bg-emerald-100 px-3 py-1.5 text-[10px] font-semibold text-emerald-700">
            ● LIVE
          </span>
        </div>
      </header>

      {/* ============================================================
          PREVIEW AREA
          ============================================================ */}

      <div
        ref={viewportRef}
        className="min-h-0 min-w-0 flex-1 overflow-auto bg-slate-100 p-4 print:block print:h-[1123px] print:w-[794px] print:overflow-visible print:bg-white print:p-0"
      >
        <div className="flex min-h-full min-w-full items-start justify-center">
          {/* ========================================================
              A4 SCALE WRAPPER
              ======================================================== */}

          <div
            className="relative shrink-0"
            style={{
              width: `${A4_WIDTH * zoom}px`,
              height: `${A4_HEIGHT * zoom}px`,
            }}
          >
            {/* ======================================================
                A4 PAGE
                ====================================================== */}

            <article
              className="absolute left-0 top-0 overflow-hidden bg-white text-black shadow-[0_2px_12px_rgba(0,0,0,0.15)] print:relative print:left-auto print:top-auto print:h-[1123px] print:w-[794px] print:transform-none print:shadow-none"
              style={{
                width: `${A4_WIDTH}px`,
                height: `${A4_HEIGHT}px`,
                transform: `scale(${zoom})`,
                transformOrigin: "top left",
                fontFamily:
                  '"Times New Roman", Times, serif',
              }}
            >
              {/* ====================================================
                  PAGE CONTENT

                  Screenshot layout:
                  left = approximately 35px
                  right = approximately 35px
                  ==================================================== */}

              <div className="absolute inset-x-[35px] top-[42px] bottom-[65px]">
                {/* ==================================================
                    TOP SECTION
                    ================================================== */}

                <div className="relative">
                  {/* =================================================
                      LOGO
                      ================================================= */}

                  <div className="absolute left-[4px] top-[0px] flex h-[44px] w-[100px] items-center justify-start">
                    {invoice.logo ? (
                      <img
                        src={invoice.logo}
                        alt="Business logo"
                        className="max-h-[44px] max-w-[100px] object-contain object-left"
                      />
                    ) : (
                      <div className="flex h-[44px] w-[100px] items-center justify-center border border-red-600">
                        <span className="font-sans text-[27px] font-bold leading-none">
                          {(invoice.businessName ||
                            "AKRA")
                            .slice(0, 4)
                            .toUpperCase()}
                        </span>
                      </div>
                    )}
                  </div>

                  {/* =================================================
                      INVOICE TITLE + META TABLE
                      ================================================= */}

                  <div className="absolute right-[15px] top-[43px] w-[196px]">
                    <div className="mb-[2px] text-[14px] font-bold">
                      Invoice
                    </div>

                    <table className="w-full border-collapse border border-black text-[12px] leading-[14px]">
                      <tbody>
                        <tr>
                          <td className="w-[95px] border border-black px-[6px] py-[1px]">
                            Date
                          </td>

                          <td className="border border-black px-[6px] py-[1px]">
                            Invoice#
                          </td>
                        </tr>

                        <tr>
                          <td className="border border-black px-[6px] py-[1px]">
                            {formatDate(
                              invoice.invoiceDate,
                            )}
                          </td>

                          <td className="border border-black px-[6px] py-[1px]">
                            {invoice.invoiceNumber ||
                              ""}
                          </td>
                        </tr>

                        <tr>
                          <td className="border border-black px-[6px] py-[1px]">
                            Due Date
                          </td>

                          <td className="border border-black px-[6px] py-[1px]">
                            {invoice.paymentTerms ||
                              ""}
                          </td>
                        </tr>

                        <tr>
                          <td className="h-[17px] border border-black px-[6px] py-[1px]">
                            &nbsp;
                          </td>

                          <td className="border border-black px-[6px] py-[1px]">
                            &nbsp;
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>

                  {/* =================================================
                      BUSINESS INFORMATION
                      ================================================= */}

                  <div className="absolute left-[1px] top-[108px] w-[330px] text-[13px] font-bold leading-[15px]">
                    <div>
                      {invoice.businessName ||
                        "AKRA Investment Services Inc"}
                    </div>

                    {businessAddressLine1 && (
                      <div>
                        {businessAddressLine1}
                      </div>
                    )}

                    {businessAddressLine2 && (
                      <div>
                        {businessAddressLine2}
                      </div>
                    )}

                    {businessAddressLine3 && (
                      <div>
                        {businessAddressLine3}
                      </div>
                    )}
                  </div>

                  {/* =================================================
                      BILL TO
                      ================================================= */}

                  <div className="absolute left-0 top-[173px] w-[282px]">
                    <div className="border border-black">
                      <div className="px-[6px] py-[2px] text-[12px] font-bold leading-[14px]">
                        Bill To
                      </div>

                      <div className="px-[6px] pb-[13px] text-[12px] leading-[15px]">
                        <div>
                          {invoice.customerName ||
                            ""}
                        </div>

                        {customerAddressLine1 && (
                          <div>
                            {customerAddressLine1}
                          </div>
                        )}

                        {customerAddressLine2 && (
                          <div>
                            {customerAddressLine2}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* =================================================
                      PHONE / EMAIL
                      ================================================= */}

                  <div className="absolute left-0 top-[278px] w-[383px]">
                    <table className="w-full border-collapse border border-black text-[12px] leading-[14px]">
                      <tbody>
                        <tr>
                          <td className="w-[145px] border border-black px-[6px] py-[1px]">
                            Phone#
                          </td>

                          <td className="border border-black px-[6px] py-[1px]">
                            Phone #{" "}
                            {customerPhone || ""}
                          </td>
                        </tr>

                        <tr>
                          <td className="border border-black px-[6px] py-[1px]">
                            Email
                          </td>

                          <td className="border border-black px-[6px] py-[1px]">
                            {invoice.customerEmail ||
                              ""}
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* ==================================================
                    ITEMS TABLE

                    Large empty rows intentionally retained to match
                    the supplied invoice layout.
                    ================================================== */}

                <div className="absolute left-0 right-0 top-[362px]">
                  <table className="w-full border-collapse border border-black text-[12px] leading-[14px]">
                    <thead>
                      <tr className="h-[17px]">
                        <th className="w-[85px] border border-black px-[6px] py-[1px] text-left font-normal">
                          Quantity
                        </th>

                        <th className="border border-black px-[6px] py-[1px] text-left font-normal">
                          Description
                        </th>

                        <th className="w-[212px] border border-black px-[6px] py-[1px] text-center font-normal">
                          Amount
                        </th>
                      </tr>
                    </thead>

                    <tbody>
                      {invoice.items.map(
                        (item, index) => {
                          const quantity =
                            Number(
                              item.quantity || 0,
                            );

                          const amount =
                            Number(
                              item.amount || 0,
                            );

                          const itemTotal =
                            quantity * amount;

                          return (
                            <tr
                              key={item.id}
                              className="h-[17px]"
                            >
                              <td className="border border-black px-[6px] py-[1px] align-top">
                                {index === 0
                                  ? item.quantity ||
                                    ""
                                  : ""}
                              </td>

                              <td className="border border-black px-[6px] py-[1px] align-top">
                                {item.description ||
                                  ""}
                              </td>

                              <td className="border border-black px-[6px] py-[1px] text-right align-top">
                                {itemTotal
                                  ? formatMoney(
                                      itemTotal,
                                      invoice.currency,
                                    )
                                  : ""}
                              </td>
                            </tr>
                          );
                        },
                      )}

                      {/* Extra blank rows to match screenshot */}

                      {Array.from({
                        length: Math.max(
                          0,
                          5 -
                            invoice.items.length -
                            1,
                        ),
                      }).map(
                        (_, index) => (
                          <tr
                            key={`blank-${index}`}
                            className="h-[17px]"
                          >
                            <td className="border border-black px-[6px] py-[1px]">
                              &nbsp;
                            </td>

                            <td className="border border-black px-[6px] py-[1px]">
                              &nbsp;
                            </td>

                            <td className="border border-black px-[6px] py-[1px]">
                              &nbsp;
                            </td>
                          </tr>
                        ),
                      )}

                      {/* TOTAL */}

                      <tr className="h-[17px]">
                        <td className="border border-black px-[6px] py-[1px]">
                          &nbsp;
                        </td>

                        <td className="border border-black px-[6px] py-[1px] text-right font-bold">
                          Total
                        </td>

                        <td className="border border-black px-[6px] py-[1px] text-right font-bold">
                          {formatMoney(
                            total,
                            invoice.currency,
                          )}
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>

                {/* ==================================================
                    PAYMENT / REMITTANCE INFORMATION
                    ================================================== */}

                <div className="absolute left-0 top-[522px] w-[650px] text-[13px] leading-[17px]">
                  <div className="mb-[2px]">
                    {invoice.notes || ""}
                  </div>

                  <div className="grid grid-cols-[130px_15px_1fr] items-baseline">
                    <strong>Bank Name</strong>
                    <strong>:</strong>
                    <span>{invoice.bankName || ""}</span>
                  </div>

                  <div className="grid grid-cols-[130px_15px_1fr] items-baseline">
                    <strong>Routing Number</strong>
                    <strong>:</strong>
                    <span>{invoice.routingNumber || ""}</span>
                  </div>

                  <div className="grid grid-cols-[130px_15px_1fr] items-baseline">
                    <strong>Account Number</strong>
                    <strong>:</strong>
                    <span>{invoice.accountNumber || ""}</span>
                  </div>
                </div>
                {/* ==================================================
                    NOTES

                    If notes are present, show them above the footer.
                    ================================================== */}
{/* ==================================================
                    SIGNATURE

                    Only appears if enabled.
                    ================================================== */}

                {invoice.requireSignature && (
                  <div className="absolute left-0 top-[670px] w-[160px] text-center text-[10px]">
                    {invoice.signature ? (
                      <img
                        src={invoice.signature}
                        alt="Customer signature"
                        className="mx-auto mb-[3px] h-[45px] w-[145px] object-contain"
                      />
                    ) : (
                      <div className="mx-auto mb-[3px] h-[45px] w-[145px] border-b border-black" />
                    )}

                    <div>
                      Authorized Signature
                    </div>
                  </div>
                )}

                {/* ==================================================
                    FOOTER

                    Red bar and contact information matching the
                    supplied reference image.
                    ================================================== */}

                <div className="absolute bottom-0 left-0 right-0 h-[52px]">
                  {/* RED BAR */}

                  <div className="absolute bottom-0 left-0 right-[205px] h-[52px] bg-[#d90000]" />

                  {/* WHITE CONTACT PANEL */}

                  <div className="absolute bottom-0 right-0 flex h-[52px] w-[205px] items-center bg-white">
                    {/* RED VERTICAL LINE */}

                    <div className="mr-[10px] h-[52px] w-[14px] bg-[#ff5a5a]" />

                    {/* CONTACT DETAILS */}

                    <div className="space-y-[2px] text-[11px] font-bold leading-[14px]">
                      <div className="flex items-center gap-[8px]">
                        <span className="font-sans text-[15px] text-red-600">
                          ☎
                        </span>

                        <span>
                          617-366-2741
                        </span>
                      </div>

                      <div className="flex items-center gap-[8px]">
                        <span className="font-sans text-[15px] text-red-600">
                          ♧
                        </span>

                        <span>
                          1 Marina Park Dr Ste 1410
                        </span>
                      </div>

                      <div className="flex items-center gap-[8px]">
                        <span className="font-sans text-[15px] text-red-600">
                          ◉
                        </span>

                        <span>
                          Boston MA 02210
                        </span>
                      </div>

                      <div className="flex items-center gap-[8px]">
                        <span className="font-sans text-[14px] text-red-600">
                          ◎
                        </span>

                        <span>
                          www.akrais.com
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </article>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ================================================================
   MONEY
   ================================================================ */

function formatMoney(
  value: number,
  currencyValue?: string,
) {
  const currencyMap: Record<
    string,
    {
      code: string;
      locale: string;
    }
  > = {
    "₹ INR": {
      code: "INR",
      locale: "en-IN",
    },

    "$ USD": {
      code: "USD",
      locale: "en-US",
    },

    "€ EUR": {
      code: "EUR",
      locale: "en-US",
    },

    "£ GBP": {
      code: "GBP",
      locale: "en-GB",
    },

    "¥ JPY": {
      code: "JPY",
      locale: "ja-JP",
    },

    "C$ CAD": {
      code: "CAD",
      locale: "en-CA",
    },

    "A$ AUD": {
      code: "AUD",
      locale: "en-AU",
    },

    "CHF CHF": {
      code: "CHF",
      locale: "de-CH",
    },

    "د.إ AED": {
      code: "AED",
      locale: "ar-AE",
    },

    "﷼ SAR": {
      code: "SAR",
      locale: "ar-SA",
    },
  };

  const selected =
    currencyMap[
      currencyValue || "$ USD"
    ] ??
    currencyMap["$ USD"];

  return new Intl.NumberFormat(
    selected.locale,
    {
      style: "currency",
      currency: selected.code,
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    },
  ).format(value || 0);
}

/* ================================================================
   DATE
   ================================================================ */

function formatDate(value: string) {
  if (!value) {
    return "";
  }

  const date = new Date(
    `${value}T00:00:00`,
  );

  if (Number.isNaN(date.getTime())) {
    return value;
  }

  return new Intl.DateTimeFormat(
    "en-US",
  ).format(date);
}