/* ============================================================
   COMPANY API
   ============================================================ */

export type CompanyRequestParam =
  | "GetCompanyList";

export interface Company {
  CompanyID: number;
  CompanyName: string;
  CompanyCode: string;
  CompanyOpenDate: string | null;
  IsActive: string;
  CompanyClosedDate: string | null;
  PrimaryPhoneNumber: string | null;
  SecondaryPhoneNumber: string | null;
  ContactName: string | null;
  ContactEmail: string | null;
  Address1: string;
  Address2: string | null;
  City: string | null;
  State: string | null;
  Country: string | null;
  ZipCode: string | null;
  ProcessTimestamp: string | null;
  BaseCurrency: string | null;
  DisplayCompanyName: string | null;
}

export interface GetCompanyListResponse {
  items: Company[];
}


/* ============================================================
   INVOICE BANK DETAILS API
   ============================================================ */

export type InvoiceBankDetailsRequestParam =
  | "GetInvoiceBankDetails";

export interface InvoiceBankDetail {
  BankID: number;
  CompanyID: number;
  BankName: string;
  RoutingNumber: string;
  AccountNumber: number | string;
  CreatedAt: unknown;
  CompanyName: string;
}

export interface GetInvoiceBankDetailsResponse {
  items: InvoiceBankDetail[];
  totalRecords: number;
  pageNumber: number;
  pageSize: number;
  totalPages: number;
  processCode: number;
}

/* ============================================================
  CUSTOMER DETAILS API
   ============================================================ */
export type CustomerRequestParam =
  | "GetCustomerDetails";

export interface Customer {
  CustomerId: string;
  CustomerName: string;
  CompanyID: string;
  CompanyName: string;
  ContactPerson: string | null;
  PhoneCountryCode: string | null;
  Phone: string | null;
  Email: string | null;
  Address1: string | null;
  Address2: string | null;
  City: string | null;
  State: string | null;
  ZipCode: string | null;
  Country: string | null;
  PaymentTerms: string | null;
  Currency: string | null;
  PaymentMethod: string | null;
  Notes: string | null;
  IsActive: boolean;
  CreatedAt: string;
}

export interface GetCustomerDetailsResponse {
  items: Customer[];
}
/* ============================================================
  Invoice DETAILS API
   ============================================================ */

export interface GetInvoiceRow {
  InvoiceID: string;
  InvoiceNumber: string;
  CustomerID: string;
  CompanyName: string;
  CompanyCode: string;
  InvoiceDate: string;
  DueDate: string;
  PaymentTerms: string;
  Currency: string;
  PaymentMethod: string;
  SubTotal: number;
  Discount: number;
  TaxAmount: number;
  ShippingAmount: number;
  TotalAmount: number;
  AmountPaid: number;
  BalanceDue: number;
  Notes: string | null;
  Status: string;
  IsActive: boolean;
  CreatedAt: string;
  UpdatedAt: string | null;

  InvoiceItemID: number;
  Description: string | null;
  Quantity: number;
  Rate: number;
  Amount: number;
}

export interface GetInvoicesResponse {
  items: GetInvoiceRow[];
  totalRecords: number;
  pageNumber: number;
  pageSize: number;
  totalPages: number;
  processCode: number;
}