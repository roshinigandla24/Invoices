import * as React from "react";
import { cn } from "@/lib/utils";

export const Input = React.forwardRef<
  HTMLInputElement,
  React.InputHTMLAttributes<HTMLInputElement>
>(({ className, ...props }, ref) => (
  <input
    ref={ref}
    className={cn(
      "w-full h-8",
      "rounded-md border border-slate-300",
      "bg-white",
      "px-2",
      "!text-[10px] !leading-4",
      "font-normal text-slate-900",
      "outline-none",
      "focus:border-blue-500",
      "focus:ring-2 focus:ring-blue-500/10",
      "placeholder:text-slate-400",
      className,
    )}
    {...props}
  />
));

Input.displayName = "Input";